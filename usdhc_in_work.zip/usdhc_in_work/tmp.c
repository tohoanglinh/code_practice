#define SDC_INSTANCE0                   (0U)        INST_USDHC1 (from cfg)
#define uSDHC_TC_TIMEOUT_MS             (5000U)     T_uSDHC_TIMEOUT_MS (TC_Common.h)
#define uSDHC_BLOCKING                  (1U)        removed.

------------------------------------------------------------------------------------------------
/*! @brief uSDHC transfer complete */
typedef enum
{
    uSDHC_TC_STATE_DONE = 0,
    uSDHC_TC_STATE_ERROR = 1
} usdhc_tc_state_t;
volatile usdhc_tc_state_t g_usdhcTransferComplete = uSDHC_TC_STATE_ERROR;
extern volatile usdhc_tc_state_t g_usdhcTransferComplete;

/*! @brief uSDHC presence */
typedef enum
{
    uSDHC_PS_STATE_NO_CARD = 0,
    uSDHC_PS_STATE_CARD_INSERTED = 1
} usdhc_ps_state_t;
volatile usdhc_ps_state_t g_usdhcPresenceStatus = uSDHC_PS_STATE_NO_CARD;
extern volatile usdhc_ps_state_t g_usdhcPresenceStatus;

/*! @brief uSDHC initialization */
typedef enum
{
    uSDHC_INIT_STATE_NOT_INITIALIZED = 0,
    uSDHC_INIT_STATE_INITIALIZED = 1
} usdhc_init_state_t;
volatile usdhc_init_state_t g_usdhcInitialized = uSDHC_INIT_STATE_NOT_INITIALIZED;
extern volatile usdhc_init_state_t g_usdhcInitialized;

------------------------------------------------------------------------------------------------
sd_card_t g_sd;         --> Tg_sd
semaphore_t g_TransferCompleteSem;   -> Tg_TransferCompleteSem
------------------------------------------------------------------------------------------------
static void uSDHC_SwitchCardDetectDat3(sd_card_t *card, bool flag);
static void uSDHC_CopyHostConfig(sd_card_t *card, const usdhc_config_t *usdhc_config);

bool uSDHC_IsSDCardWriteProtect(void);
bool uSDHC_IsSDCardPresent(void);
sd_card_t *uSDHC_GetSDCard(void);

common_status_t uSDHC_Init(bool wouldBlock);
common_status_t uSDHC_DeInit(void);

status_t uSDHC_TransferFunction(uint32_t instance, usdhc_transfer_t *content);

void uSDHC_TransferCompleteCallback(uint32_t instance, uint32_t status, void *userData);
void uSDHC_CardInsertCallback(uint32_t instance, uint32_t status, void *userData);
void uSDHC_CardRemoveCallback(uint32_t instance, uint32_t status, void *userData);
