
/*!
 * @brief Transfer data using uSDHC_DRV_Transfer.
 *
 * @param[in]  instance  uSDHC instance number.
 * @param[in]  transfer  Transfer content including the command or data.

 * @return STATUS_SUCCESS  if transfer is successful.
 *         STATUS_ERROR    if other errors happen.
 */
status_t T_uSDHC_TransferNonBlockingFunction(uint32_t instance,
                                           usdhc_transfer_t * transfer);

/*!
 * @brief Transfer data using uSDHC_DRV_TransferBlocking.
 *
 * @param[in]  instance  uSDHC instance number.
 * @param[in]  transfer  Transfer content including the command or data.

 * @return STATUS_SUCCESS  if transfer is successful.
 *         STATUS_ERROR    if other errors happen.
 */
status_t T_uSDHC_TransferBlockingFunction(uint32_t instance,
                                        usdhc_transfer_t * transfer);

/*!
 * @brief callback functions for
 *        dedicated events for interrupt test.
 *
 * @param[in]  instance  uSDHC instance number.
 * @param[in]  status    Transfer result code.
 * @param[in]  userData  User defined data.
 *
 * @return NONE.
 */
void T_uSDHC_TransferCompleteCallbackMod(uint32_t instance,
                                       uint32_t status,
                                       void *userData);

void T_uSDHC_CardInterruptCallback(uint32_t instance,
                                 uint32_t status,
                                 void *userData);

void T_uSDHC_BlockGapCallback(uint32_t instance,
                            uint32_t status,
                            void *userData);
