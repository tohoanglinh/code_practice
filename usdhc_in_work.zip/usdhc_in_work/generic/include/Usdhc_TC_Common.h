/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file    Usdhc_TC_Common.h
*
*   @brief   Test case common header file
*   @details Test case common header file
*
*   @addtogroup USDHC_TESTS
*   @{
*/
#ifndef USDHC_TC_COMMON_H
#define USDHC_TC_COMMON_H
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
/* standard library */
#include "stdint.h"
#include "stdbool.h"
#include "stdio.h"
#include "stddef.h"
#include "stdlib.h"
#include "float.h"
#include "Std_Types.h"

/* eunit tests */
#include "EUnit_Types.h"
#include "EUnit_Api.h"
#include "EUnit.h"

/* internal modules (device, drivers) */
#include "device_registers.h"
#include "clock_MPC57xx.h"
#include "clock.h"
#include "clock_manager.h"
#include "interrupt_manager.h"

/* usdhc driver */
#include "usdhc_driver.h"
#include "usdhc_hw_access.h"

/* sdhc stack: sd layer */
#include "sd/card.h"
#include "sd/common.h"
#include "sd/sdmmc.h"
#include "sd/sdspi.h"
#include "sd/spec.h"

/* generated configuration code from Processor Expert */
#include "Cpu.h"
#include "usdhc1.h"
#include "pin_mux.h"
#include "clockMan1.h"

/* vnv tools */
#include "custom_devassert.h"

#ifdef CCOV_ENABLE
#include "ccov_main.h"
#endif

#ifdef T32_TRACE_APP
#include "sys_trace.h"
#endif
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/


/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/


/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
/* GPR byte swap */
#define T_GPR_BYTE_SWAP                                 (0x01U)

/* uSDHC test macros */

/*! @brief uSDHC data macros */
#define T_uSDHC_DATA_BLOCK_START                        (0U)
#define T_uSDHC_DATA_DEFAULT_BLOCK_SIZE                 (512U)
#define T_uSDHC_SINGLE_BLOCK                            (1U)
#define T_uSDHC_MULTI_BLOCKS                            (10U)
#if defined uSDHC_ENABLE_ADMA1
/* 119 max for ADMA1 with table size min = 8 bytes */
#define T_uSDHC_MULTI_BLOCKS_MAX                        (uSDHC_ADMA1_DESCRIPTOR_MAX_LENGTH_PER_ENTRY / T_uSDHC_DATA_DEFAULT_BLOCK_SIZE)
/* 168 max for ADMA1 with table size up to 65535 bytes, depends on MCU memory */
/* #define T_uSDHC_MULTI_BLOCKS_MAX                        (168U) */
#else
/* 127 max for ADMA2 with table size min = 8 bytes */
#define T_uSDHC_MULTI_BLOCKS_MAX                        (uSDHC_ADMA2_DESCRIPTOR_MAX_LENGTH_PER_ENTRY / T_uSDHC_DATA_DEFAULT_BLOCK_SIZE)
/* 175 max for ADMA2 with table size up to 65535 bytes, depends on MCU memory */
/* #define T_uSDHC_MULTI_BLOCKS_MAX                        (175U) */
#endif
#define T_uSDHC_DATA_BLOCK_COUNT                        (T_uSDHC_MULTI_BLOCKS_MAX)
#define T_uSDHC_DATA_BUFFER_SIZE                        (T_uSDHC_DATA_DEFAULT_BLOCK_SIZE * T_uSDHC_DATA_BLOCK_COUNT)
#define T_uSDHC_MAX_BLOCK_LENGTH                        (4096U)
#define T_uSDHC_MAX_BLOCK_COUNT                         (0xFFFFU)

/*! @brief uSDHC general macros */
#define T_uSDHC_TIMEOUT_MS                              (1000U)
#define T_uSDHC_INVALID_INSTANCE                        (2U)

/*! @brief uSDHC other macros */
#define T_uSDHC_LOOP_COUNT                              (5U)
#define T_uSDHC_RESET_MASK                              (0x07000000u)
#define T_uSDHC_BUS_CLOCK                               (8000000U)
#define T_uSDHC_GATE_OFF_DISABLED                       (1U)
#define T_uSDHC_INT_EN                                  (0x17f0033U)
#define T_uSDHC_INTERRUPT_DEFAULT_PRIORITY              (15U)
#define T_uSDHC_SPEC_VERSION                            (0x02U)
#define T_uSDHC_VENDOR_VERSION                          (0x03U)
#define T_uSDHC_PRES_STATE_INIT                         (0x000D8088U)
#define T_uSDHC_PRES_STATE_INIT_PINS_STABLE             (0x088D8088U)
#define T_uSDHC_WATERMARK_LEVEL_MAX                     (128U)
#define T_uSDHC_WATERMARK_LEVEL_RAND                    (80U)

/*! @brief uSDHC on-off test macros */
#define T_uSDHC_INTERRUPT_ENABLED                       (1U)
#define T_uSDHC_INTERRUPT_DISABLED                      (0U)
#define T_uSDHC_BLOCKCOUNT_ENABLED                      (1U)
#define T_uSDHC_BLOCKCOUNT_DISABLED                     (0U)
#define T_uSDHC_DAT3_CARD_DETECTION_PIN_ENABLED         (1U)
#define T_uSDHC_DAT3_CARD_DETECTION_PIN_DISABLED        (0U)
#define T_uSDHC_CARD_CONTROL_ENABLED                    (1U)
#define T_uSDHC_CARD_CONTROL_DISABLED                   (0U)
#define T_uSDHC_CARD_INSERTED                           (1U)
#define T_uSDHC_CARD_REMOVED                            (0U)

/*! @brief uSDHC interrupt indexes macros */
#define T_uSDHC_COMMAND_COMPLETE_INT_INDEX              (0U)
#define T_uSDHC_DATA_COMPLETE_INT_INDEX                 (1U)
#define T_uSDHC_BLOCK_GAP_INT_INDEX                     (2U)
#define T_uSDHC_DMA_COMPLETE_INT_INDEX                  (3U)
#define T_uSDHC_BUFFER_WRITE_READY_INT_INDEX            (4U)
#define T_uSDHC_BUFFER_READ_READY_INT_INDEX             (5U)
#define T_uSDHC_CARD_INSERT_INT_INDEX                   (6U)
#define T_uSDHC_CARD_REMOVE_INT_INDEX                   (7U)
#define T_uSDHC_CARD_INTERRUPT_INT_INDEX                (8U)
#define T_uSDHC_COMMAND_TIMEOUT_INT_INDEX               (9U)
#define T_uSDHC_COMMAND_CRC_ERROR_INT_INDEX             (10U)
#define T_uSDHC_COMMAND_ENDBIT_ERROR_INT_INDEX          (11U)
#define T_uSDHC_COMMAND_INDEX_ERROR_INT_INDEX           (12U)
#define T_uSDHC_DATA_TIMEOUT_INT_INDEX                  (13U)
#define T_uSDHC_DATA_CRC_ERROR_INT_INDEX                (14U)
#define T_uSDHC_DATA_ENDBIT_ERROR_INT_INDEX             (15U)
#define T_uSDHC_AUTO_CMD12_ERROR_INT_INDEX              (16U)
#define T_uSDHC_DMA_ERROR_INT_INDEX                     (17U)
#define T_uSDHC_NUM_INTERRUPTS                          (18U)

/* Card test macros */
#define T_CARD_ERASED_DATA                              (0x00U)

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/
extern volatile bool Tg_uSDHC_Interrupt[T_uSDHC_NUM_INTERRUPTS];
extern volatile uint32_t Tg_uSDHC_PresentStatus;
extern sd_card_t Tg_sd;

/* data transfer (write/read) variable and alignment for ADMA1, ADMA2
 * Because: ADMA1 only supports 4KB=4096B aligned data in system memory to transfer
 * Because: ADMA2 supports any location and any size to transfer
 */
#if defined uSDHC_ENABLE_ADMA1
  ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
  extern uint8_t g_dataWriteADMA1[T_uSDHC_DATA_BUFFER_SIZE];

  ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
  extern uint8_t g_dataReadADMA1[T_uSDHC_DATA_BUFFER_SIZE];
#else
  ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
  extern uint8_t g_dataWrite[T_uSDHC_DATA_BUFFER_SIZE];

  ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
  extern uint8_t g_dataRead[T_uSDHC_DATA_BUFFER_SIZE];
#endif /* uSDHC_ENABLE_ADMA1 */

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

/*!
 * @brief Check a development error should be detected with invalid configurations.
 *
 * @param NONE.
 *
 * @return NONE.
 */
void checkDevError(void);

/*!
 * @brief Prepare an array of data for testing.
 *
 * @param[out] data     store output number data into the array "data".
 * @param[in]  size     size of array.
 *
 * @return NONE.
 */
void prepareData(uint8_t * data,
                 uint32_t size);

/*!
 * @brief Reset all interrupt monitors (array) before execute a test case.
 *
 * @param NONE.
 *
 * @return NONE.
 */
void resetInterruptMonitor(void);

status_t T_uSDHC_Init(void);
status_t T_uSDHC_Deinit(void);
status_t T_uSDHC_TransferBlockingFunction(uint32_t instance, usdhc_transfer_t * transfer);
status_t T_uSDHC_TransferFunction(uint32_t instance, usdhc_transfer_t * transfer);
void T_uSDHC_TransferCompleteCallback(uint32_t instance, uint32_t status, void *userData);
void T_uSDHC_CardInsertCallback(uint32_t instance, uint32_t status, void *userData);
void T_uSDHC_CardRemoveCallback(uint32_t instance, uint32_t status, void *userData);
void T_uSDHC_BlockGapCallback(uint32_t instance, uint32_t status, void *userData);
void T_uSDHC_CardInterruptCallback(uint32_t instance, uint32_t status, void *userData);

#if defined(__cplusplus)
}
#endif

#endif /* USDHC_TC_COMMON_H */

/** @} */
