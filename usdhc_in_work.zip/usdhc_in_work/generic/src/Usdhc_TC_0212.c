/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file    Usdhc_TC_0212.c
*
*   @brief   Usdhc test case 0212.
*   @details Usdhc test case 0212 for transfer data.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "Usdhc_TC_0212.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0212
* @brief          Write Read Erase: max multiple data blocks (ADMA1).
* @details        Write Read Erase: max multiple data blocks (ADMA1).
* @pre            N/A.
* @post           N/A.
*
* @test_level     Component Validation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Invoke uSDHC_Init(true)
*                     -# Prepare data arrays for write and read sessions
*                     -# Write data to card
*                     -# Verification Point:
*                           - SD_WriteBlocks returns STATUS_SUCCESS
*                     -# Read data from card after writing
*                     -# Verification Point:
*                           - SD_ReadBlocks returns STATUS_SUCCESS
*                     -# Compare data between read and write after writing
*                     -# Verification point:
*                        - Read data should be matched with Write data
*                     -# Erase data from card
*                     -# Verification Point:
*                           - SD_EraseBlocks returns STATUS_SUCCESS
*                     -# Read data from card after erasing
*                     -# Verification Point:
*                           - SD_ReadBlocks returns STATUS_SUCCESS
*                     -# Compare data between read and write after erasing
*                        - Read data should be cleared
*                     -# Invoke uSDHC_DeInit()
* @pass_criteria  Verification Points are successful
*
* @requirements   uSDHC_020_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      SD Card
* @sw_depend      SDHC Middleware
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords       N/A
*/
void Usdhc_TC_0212(void)
{
    /* Local variables */
    common_status_t T_uSDHC_Status = (common_status_t)STATUS_ERROR;
    sd_card_t *card = &g_sd;

    /* uint32_t numBlocks = card->host.capability.maxBlockCount; */
    uint32_t numBlocks = T_uSDHC_MULTI_BLOCKS_MAX;
    uint32_t blockAddress = DATA_BLOCK_START;
    uint32_t blockSize = DATA_DEFAULT_BLOCK_SIZE;

    /* INIT MODULE: Initialize uSDHC driver and card */
    uSDHC_Init(true);

    /* configure to use transfer blocking function */
    card->host.transfer = T_uSDHC_TransferBlockingFunction;

    /* PREPARE DATA: Prepare a data array for a write session */
    (void)prepareData(g_dataWriteADMA1, numBlocks*blockSize);

    /* PREPARE DATA: Erase a data array for a read session */
    (void)memset(g_dataReadADMA1, T_uSDHC_ERASED_DATA, numBlocks*blockSize);

    /* TRANSFER DATA: Write data to card */
    T_uSDHC_Status = SD_WriteBlocks(card, g_dataWriteADMA1, blockAddress, numBlocks);
    EU_ASSERT((common_status_t)STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after writing */
    T_uSDHC_Status = SD_ReadBlocks(card, g_dataReadADMA1, blockAddress, numBlocks);
    EU_ASSERT((common_status_t)STATUS_SUCCESS == T_uSDHC_Status);

    /* COMPARE DATA: Compare between Read and Write after writing session */
    EU_ASSERT(0U == memcmp(g_dataReadADMA1, g_dataWriteADMA1, numBlocks*blockSize));

    /* TRANSFER DATA: Erase data from card */
    T_uSDHC_Status = SD_EraseBlocks(card, blockAddress, numBlocks);
    EU_ASSERT((common_status_t)STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after erasing */
    T_uSDHC_Status = SD_ReadBlocks(card, g_dataReadADMA1, blockAddress, numBlocks);
    EU_ASSERT((common_status_t)STATUS_SUCCESS == T_uSDHC_Status);

    /* PREPARE DATA: Erase the write data array for a comparing session */
    (void)memset(g_dataWriteADMA1, T_uSDHC_ERASED_DATA, numBlocks*blockSize);

    /* COMPARE DATA: Compare between Read and Write after erasing session */
    EU_ASSERT(0U == memcmp(g_dataReadADMA1, g_dataWriteADMA1, numBlocks*blockSize));

    /* DEINIT MODULE: De-initialize uSDHC driver and card */
    uSDHC_DeInit();
}


#ifdef __cplusplus
}
#endif

/** @} */
