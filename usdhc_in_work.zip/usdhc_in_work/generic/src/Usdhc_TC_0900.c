/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0900.c
*
*   @brief   Test case 0900.
*   @details Function test case 0900.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0900.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/
static const IRQn_Type T_usdhcTxIrqId[] = uSDHC_IRQS;

/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0900
* @brief          Check functionality of uSDHC_DRV_Init with a single configuration and uSDHC_DRV_Deinit.
* @details        This test case checks functional of uSDHC_DRV_Init with a single configuration
*                 and uSDHC_DRV_Deinit.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly
*                        - All auto gated off features are disabled
*                        - uSDHC byte_swapper is set
*                        - Interrupt Status Enable and Interrupt Signal Enable register is setup correctly
*                        - The interrupt for uSDHC IRQ and interrupt priority are set
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - Interrupt Status Enable and Interrupt Signal Enable register are cleared
*                        - The interrupt for uSDHC IRQ and interrupt priority are cleared
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_006_001,
*                 uSDHC_007_001, uSDHC_004_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0900(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* Initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_NO == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Verification point: All auto gated off features are disabled */
    EU_ASSERT(T_uSDHC_GATE_OFF_DISABLED == ((Base->VEND_SPEC) & \
              uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_GATE_OFF_DISABLED == ((Base->VEND_SPEC) & \
              uSDHC_VEND_SPEC_HCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_HCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_GATE_OFF_DISABLED == ((Base->VEND_SPEC) & \
              uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_SHIFT);

    /* Verification point: uSDHC byte_swapper is set */
    EU_ASSERT(T_GPR_uSDHC_BYTE_SWAP == ((GPR->CTL) & GPR_CTL_USDHC_BS_MASK) >> GPR_CTL_USDHC_BS_SHIFT);

    /* Verification point: Interrupt Status Enable and Interrupt Signal Enable register
       is setup correctly */
    EU_ASSERT(T_uSDHC_INT_EN == Base->INT_STATUS_EN);
    EU_ASSERT(T_uSDHC_INT_EN == Base->INT_SIGNAL_EN);

    /* Verification point: The interrupt for uSDHC IRQ and interrupt priority are set */
    EU_ASSERT(T_INTERRUPT_ENABLED == (INTC->PSR[(int32_t)T_usdhcTxIrqId[INST_USDHC1]] & \
                                      INTC_PSR_PRC_SELN0_MASK) >> INTC_PSR_PRC_SELN0_SHIFT);
    EU_ASSERT(T_INTERRUPT_DEFAULT_PRIORITY == (INTC->PSR[(int32_t)T_usdhcTxIrqId[INST_USDHC1]] & \
                                               INTC_PSR_PRIN_MASK) >> INTC_PSR_PRIN_SHIFT);

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: Interrupt Status Enable and Interrupt Signal Enable register are cleared */
    EU_ASSERT(T_INTERRUPT_DISABLED == Base->INT_STATUS_EN);
    EU_ASSERT(T_INTERRUPT_DISABLED == Base->INT_SIGNAL_EN);

    /* Verification point: The interrupt for uSDHC IRQ and interrupt priority are cleared */
    EU_ASSERT(T_INTERRUPT_DISABLED == (INTC->PSR[(int32_t)T_usdhcTxIrqId[INST_USDHC1]] & \
                                       INTC_PSR_PRC_SELN0_MASK) >> INTC_PSR_PRC_SELN0_SHIFT);

    EU_ASSERT(T_INTERRUPT_DISABLED == (INTC->PSR[(int32_t)T_usdhcTxIrqId[INST_USDHC1]] & \
                                       INTC_PSR_PRIN_MASK) >> INTC_PSR_PRIN_SHIFT);
}

#ifdef __cplusplus
}
#endif

/** @} */
