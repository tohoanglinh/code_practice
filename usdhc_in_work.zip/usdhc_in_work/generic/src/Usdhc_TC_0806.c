/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0806.c
*
*   @brief   Test case 0806.
*   @details Function test case 0806.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0806.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0806
* @brief          Check functionality of uSDHC_DRV_InstallCallback.
* @details        This test case checks uSDHC_DRV_InstallCallback functionality.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC driver module by calling uSDHC_DRV_Init with configuration 0
*                     -# Verification point:
*                        - Initialize uSDHC returns STATUS_SUCCESS
*                     -# Install/De-install callback functions for each corresponding event
*                     -# Verification point:
*                        - Callback functions are setup correctly
*                        - Interrupts status enable register are setup correctly
*                        - Card Interrupt enable bits have been disabled right away
*                     -# Deinitialize uSDHC driver.
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_023_001, uSDHC_023_002, uSDHC_080_001, uSDHC_012_001
*                 uSDHC_004_001, uSDHC_012_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0806(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* Initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Install callbacks and enable interrupts */
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, uSDHC_TransferCompleteCallback, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, uSDHC_CardInsertCallback, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, uSDHC_CardRemoveCallback, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, uSDHC_BlockGapCallback, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, uSDHC_CardInterruptCallback, NULL);

    /* Verification point: callback functions are setup correctly */
    EU_ASSERT((usdhc_callback_t)uSDHC_TransferCompleteCallback == usdhc1_State.transferCallback);
    EU_ASSERT((usdhc_callback_t)uSDHC_CardInsertCallback == usdhc1_State.cardInsertCallback);
    EU_ASSERT((usdhc_callback_t)uSDHC_CardRemoveCallback == usdhc1_State.cardRemoveCallback);
    EU_ASSERT((usdhc_callback_t)uSDHC_BlockGapCallback == usdhc1_State.blockGapCallback);
    EU_ASSERT((usdhc_callback_t)uSDHC_CardInterruptCallback == usdhc1_State.cardIntCallback);

    /* Verification point: interrupts correspond to each event are setup correctly */
    EU_ASSERT(uSDHC_INT_STATUS_EN_CINSSEN_MASK == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CINSSEN_MASK));
    EU_ASSERT(uSDHC_INT_STATUS_EN_CRMSEN_MASK == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CRMSEN_MASK));
    EU_ASSERT(uSDHC_INT_STATUS_EN_BGESEN_MASK == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_BGESEN_MASK));
    EU_ASSERT(0U == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CINTSEN_MASK));
    EU_ASSERT(0U == ((Base->INT_SIGNAL_EN) & uSDHC_INT_SIGNAL_EN_CINTIEN_MASK));

    /* De-install callbacks and disable interrupts  */
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, NULL, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, NULL, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, NULL, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, NULL, NULL);
    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, NULL, NULL);

    /* Verification point: callback functions are setup correctly */
    EU_ASSERT(NULL == usdhc1_State.transferCallback);
    EU_ASSERT(NULL == usdhc1_State.cardInsertCallback);
    EU_ASSERT(NULL == usdhc1_State.cardRemoveCallback);
    EU_ASSERT(NULL == usdhc1_State.blockGapCallback);
    EU_ASSERT(NULL == usdhc1_State.cardIntCallback);

    /* Verification point: interrupts correspond to each event are setup correctly */
    EU_ASSERT(0U == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CINSSEN_MASK));
    EU_ASSERT(0U == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CRMSEN_MASK));
    EU_ASSERT(0U == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_BGESEN_MASK));
    EU_ASSERT(0U == ((Base->INT_STATUS_EN) & uSDHC_INT_STATUS_EN_CINTSEN_MASK));

    /* De-initialize uSDHC module */
    (void)uSDHC_DRV_Deinit(INST_USDHC1);
}

#ifdef __cplusplus
}
#endif

/** @} */
