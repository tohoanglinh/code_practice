/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file    Usdhc_TC_Common.c
*
*   @brief   Test case common source file
*   @details Test case common source file
*
*   @addtogroup USDHC_TESTS
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_Common.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/



/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/
volatile bool Tg_uSDHC_Interrupt[T_uSDHC_NUM_INTERRUPTS] = { false };
volatile uint32_t Tg_uSDHC_PresentStatus;
sd_card_t Tg_sd;

/* data transfer (write/read) variable and alignment for ADMA1, ADMA2
 * Because: ADMA1 only supports 4KB=4096B aligned data in system memory to transfer
 * Because: ADMA2 supports any location and any size to transfer
 */
#if defined uSDHC_ENABLE_ADMA1
    ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
    uint8_t g_dataWriteADMA1[T_uSDHC_DATA_BUFFER_SIZE];

    ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
    uint8_t g_dataReadADMA1[T_uSDHC_DATA_BUFFER_SIZE];
#else
    ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
    uint8_t g_dataWrite[T_uSDHC_DATA_BUFFER_SIZE];

    ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
    uint8_t g_dataRead[T_uSDHC_DATA_BUFFER_SIZE];
#endif /* uSDHC_ENABLE_ADMA1 */

/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
static void T_uSDHC_CheckInterrupt(uint32_t instance);
static bool T_uSDHC_IsSDCardPresent(sd_card_t *card);

/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_CheckInterrupt
 * Description   : Check what type of interrupt has been occurred.
 *
 *END**************************************************************************/
static void T_uSDHC_CheckInterrupt(uint32_t instance)
{
    uSDHC_Type * base = g_usdhcBases[instance];
    uint32_t interruptFlags = 0U;

    interruptFlags = uSDHC_GetInterruptStatusFlags(base);
    switch (interruptFlags)
    {
        case uSDHC_COMMAND_COMPLETE_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_COMMAND_COMPLETE_INT_INDEX] = true;
            break;
        case uSDHC_DATA_COMPLETE_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DATA_COMPLETE_INT_INDEX] = true;
            break;
        case uSDHC_BLOCK_GAP_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_BLOCK_GAP_INT_INDEX] = true;
            break;
        case uSDHC_DMA_COMPLETE_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DMA_COMPLETE_INT_INDEX] = true;
            break;
        case uSDHC_BUFFER_WRITE_READY_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_BUFFER_WRITE_READY_INT_INDEX] = true;
            break;
        case uSDHC_BUFFER_READ_READY_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_BUFFER_READ_READY_INT_INDEX] = true;
            break;
        case uSDHC_CARD_INSERT_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_CARD_INSERT_INT_INDEX] = true;
            break;
        case uSDHC_CARD_REMOVE_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_CARD_REMOVE_INT_INDEX] = true;
            break;
        case uSDHC_CARD_INTERRUPT_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_CARD_INTERRUPT_INT_INDEX] = true;
            break;
        case uSDHC_COMMAND_TIMEOUT_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_COMMAND_TIMEOUT_INT_INDEX] = true;
            break;
        case uSDHC_COMMAND_CRC_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_COMMAND_CRC_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_COMMAND_ENDBIT_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_COMMAND_ENDBIT_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_COMMAND_INDEX_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_COMMAND_INDEX_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_DATA_TIMEOUT_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DATA_TIMEOUT_INT_INDEX] = true;
            break;
        case uSDHC_DATA_CRC_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DATA_CRC_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_DATA_ENDBIT_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DATA_ENDBIT_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_AUTO_CMD12_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_AUTO_CMD12_ERROR_INT_INDEX] = true;
            break;
        case uSDHC_DMA_ERROR_INT:
            Tg_uSDHC_Interrupt[T_uSDHC_DMA_ERROR_INT_INDEX] = true;
            break;
        default:
            break;
    }
}

static bool T_uSDHC_IsSDCardPresent(sd_card_t *card)
{
    if(1U == (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & (uint32_t)uSDHC_CARD_INSERTED))
    {
        return true;
    }
    else
    {
        return false;
    }
}

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*FUNCTION**********************************************************************
 *
 * Function Name : checkDevError
 * Description   : Check a development error should be detected with invalid configurations.
 *
 *END**************************************************************************/
void checkDevError(void)
{
    /* check if Dev_ErrorId has been toggled due to error */
    EU_ASSERT(Dev_ErrorId == 1);

    /* clear Dev_ErrorId */
    Dev_ErrorId = 0;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : prepareData
 * Description   : Prepare data for writing.
 *
 *END**************************************************************************/
void prepareData(uint8_t * data, uint32_t size)
{
    uint32_t i = 0U;

    for (i = 0U; i < size; i++)
    {
        data[i] = (uint8_t)i;
    }
}

/*FUNCTION**********************************************************************
 *
 * Function Name : resetInterruptMonitor
 * Description   : Reset all interrupt monitors (array) before execute a test case.
 *
 *END**************************************************************************/
void resetInterruptMonitor(void)
{
    uint8_t i;

    for (i = 0U; i < T_uSDHC_NUM_INTERRUPTS; i++)
    {
        Tg_uSDHC_Interrupt[i] = false;
    }
}

/*
 * STATUS_ERROR: init fail, no card, SD_Init fails
 */
status_t T_uSDHC_Init(void)
{
    status_t status = STATUS_ERROR;
    usdhc_config_t *usdhc_config = &usdhc1_Config0;
    sd_card_t *card = &Tg_sd;

    /* clear card pointer */
    (void)memset(card, 0U, sizeof(sd_card_t));

    /* init usdhc host driver */
    status = uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, usdhc_config);
    if (STATUS_SUCCESS == status)
    {
        /* install callback functions */
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, T_uSDHC_TransferCompleteCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, T_uSDHC_CardInsertCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, T_uSDHC_CardRemoveCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, T_uSDHC_BlockGapCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, T_uSDHC_CardInterruptCallback, NULL);

        /* save host information to card, must do before sd_init */
        card->host.instance = INST_USDHC1;
        card->host.config->endianMode = usdhc_config->endianMode;
        card->host.config->dmaMode = usdhc_config->dmaMode;
        card->host.config->admaTable = usdhc_config->admaTable;
        card->host.config->admaTableSize = usdhc_config->admaTableSize;
        card->host.config->cardDetectDat3 = false;          /* card detection isn't implemented in SD layer */
        card->host.transfer = T_uSDHC_TransferFunction;

        /* if a card is present, init the card */
        if (true == T_uSDHC_IsSDCardPresent(card))
        {
            status = (status_t)SD_Init(card);
        }
        else
        {
            status = STATUS_ERROR;
        }

        /* DAT3 does not monitor card insertion */
        g_usdhcBases[INST_USDHC1]->PROT_CTRL &= ~(uint32_t)uSDHC_PROT_CTRL_D3CD_MASK;
    }

    return status;
}

/*
 * STATUS_ERROR: no card, SD_DeInit fails, deinit fails, reset timeout
 */
status_t T_uSDHC_Deinit(void)
{
    status_t status = STATUS_ERROR;
    sd_card_t *card = &Tg_sd;

    if (true == T_uSDHC_IsSDCardPresent(card))
    {
        status = SD_DeInit(card);
        if (STATUS_SUCCESS == status)
        {
            status = uSDHC_DRV_Deinit(INST_USDHC1);
            if (STATUS_SUCCESS == status)
            {
                status = uSDHC_DRV_Reset(INST_USDHC1, uSDHC_RESET_ALL, T_uSDHC_TIMEOUT_MS);
                if (STATUS_SUCCESS != status)
                {
                    status = STATUS_ERROR;
                }
            }
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, NULL, NULL);
        }
    }

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferBlockingFunction
 * Description   : Transfer data using uSDHC_DRV_TransferBlocking function, blocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferBlockingFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t status = STATUS_ERROR;

    do
    {
        status = uSDHC_DRV_TransferBlocking(instance, transfer, T_uSDHC_TIMEOUT_MS);
        if (STATUS_SUCCESS == status)
        {
            break;
        }
    } while (STATUS_BUSY == status);

    return status;
}


/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferFunction
 * Description   : Transfer data using uSDHC_DRV_Transfer function, non-blocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t status = STATUS_ERROR;

    do
    {
        status = uSDHC_DRV_Transfer(instance, transfer);
        if (STATUS_SUCCESS == status)
        {
            status = OSIF_SemaWait(&usdhc1_State->semaTransferComplete, T_uSDHC_TIMEOUT_MS);
            if (STATUS_SUCCESS != status)
            {
                break;
            }
        }
    } while (STATUS_BUSY == status);

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferCompleteCallback
 * Description   : Transfer complete callback function.
 *
 *END**************************************************************************/
void T_uSDHC_TransferCompleteCallback(uint32_t instance, uint32_t status, void *userData)
{

}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardInsertCallback
 * Description   : Card insert callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardInsertCallback(uint32_t instance, uint32_t status, void *userData)
{

}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardRemoveCallback
 * Description   : Card remove callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardRemoveCallback(uint32_t instance, uint32_t status, void *userData)
{

}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_BlockGapCallback
 * Description   : Block gap callback function.
 *
 *END**************************************************************************/
void T_uSDHC_BlockGapCallback(uint32_t instance, uint32_t status, void *userData)
{

}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardInterruptCallback
 * Description   : Card interrupt callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardInterruptCallback(uint32_t instance, uint32_t status, void *userData)
{

}

/*!
 * @brief Callback function for uSDHC
 *
 * @param instance  uSDHC number instance invoking this function
 * @param status    This parameter is used for transfer complete callback function. It indicates the status of a transfer.
 *                  In case of success, value of status is STATUS_SUCCESS and in case of failure, this value will contain the interrupt flag
 *                  of uSDHC module. User can do a logical OR of this value with "usdhc_interrupt_t" enumeration to know what error happened
 * @param param     The user data that registered before by InstallCallback functions
 * Implements : usdhc_callback_t_Class
 */
// typedef void (*usdhc_callback_t)(uint32_t instance, uint32_t status, void * param);

#ifdef __cplusplus
}
#endif

/** @} */
