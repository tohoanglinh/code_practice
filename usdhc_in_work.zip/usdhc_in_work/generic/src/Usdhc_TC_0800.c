/**
*   Copyright 2017-2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0800.c
*
*   @brief   Test case 0800.
*   @details Function test case 0800.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0800.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0800
* @brief          Check functionality of uSDHC_DRV_GetPresentStatusFlags.
* @details        This test case checks uSDHC_DRV_GetPresentStatusFlags function when
*                 the pins for uSDHC module are configured and there is a card in socket.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init when the 4 pins
*                        (DAT0, DAT1, DAT2 and DAT3) for uSDHC module are configured and there is
*                        a card in socket
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*                     -# Get the present status of uSDHC
*                     -# Verification point: The function returns correct values of
*                        - DAT0-DAT3,
*                        - CMD line signal level,
*                        - card is inserted,
*                        - SD clock is gated off,
*                        - SD clock stable
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_031_001,
*                 uSDHC_031_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords       N/A
*/

void Usdhc_TC_0800(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;

    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                   &usdhc1_State,
                                   &usdhc1_Config0);

    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    OSIF_TimeDelay(2U);

    /* Get the present status of uSDHC */
    Tg_uSDHC_PresentStatus = uSDHC_DRV_GetPresentStatusFlags(INST_USDHC1);

    /* Verification point: The function returns correct value of DAT0-DAT3, CMD line signal level
       card is inserted, SD clock is gated off, SD clock is stable */
    EU_ASSERT(Tg_uSDHC_PresentStatus == T_uSDHC_PRES_STATE_INIT_PINS_STABLE);

    /* Deinit the module uSDHC DRV */
    EU_ASSERT(STATUS_SUCCESS == uSDHC_DRV_Deinit(INST_USDHC1));
}

#ifdef __cplusplus
}
#endif

/** @} */
