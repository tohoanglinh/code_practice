/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0905.c
*
*   @brief   Test case 0905.
*   @details Function test case 0905.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0905.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0905
* @brief          Check functionality of Card Detection using pin DAT3 without card.
* @details        This test case checks DAT3 Pin functionality as Card Detection without card.
* @pre            No card
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Configure DAT3 pin as pull down
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init with configuration 1 (DAT3 = false)
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly with DAT3 detection false
*                     -# Get present status flags by invoking uSDHC_DRV_GetPresentStatusFlags
*                     -# Verification point:
*                        - In register PROT_CTRL, CINST bit is 1 even no card due to DAT3 detection is false
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init with configuration 8 (DAT3 = true)
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly with DAT3 detection true
*                     -# Get present status flags by invoking uSDHC_DRV_GetPresentStatusFlags
*                     -# Verification point:
*                        - In register PROT_CTRL, CINST bit is 0 which indicates no card due to DAT3 detection is true
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_002_001, uSDHC_023_001, uSDHC_023_002, uSDHC_011_001, uSDHC_013_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0905(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* uSDHC_DAT3 pin - PI0: PUS = 0 --> pull select as Pull-down;
                             PUS = 1 --> pull select as Pull-up */
    SIUL2->MSCR[128] = SIUL2_MSCR_IBE(1) | SIUL2_MSCR_OBE(1) | SIUL2_MSCR_PUE(1) | SIUL2_MSCR_PUS(0) | SIUL2_MSCR_SRC(3) | SIUL2_MSCR_SSS(4);
    SIUL2->IMCR[985 - 512] = SIUL2_IMCR_SSS(2);

    /* Initialize uSDHC module with configuration 1 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);

    /* wait a moment before getting updated present status flags from uSDHC_PRES_STATE register */
    OSIF_TimeDelay(2U);

    /* Verification point: if card detection pin feature is OFF, then after initializing, CINST = 1 even no card due to DAT3 card detection is false */
    Tg_uSDHC_PresentStatus = uSDHC_DRV_GetPresentStatusFlags(INST_USDHC1);
    EU_ASSERT(T_uSDHC_CARD_INSERTED == ((Tg_uSDHC_PresentStatus & uSDHC_CARD_INSERTED) >>
                                                   uSDHC_PRES_STATE_CINST_SHIFT));

    /* Initialize uSDHC module with configuration 8 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config8);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_ON == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);

    uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, uSDHC_CardRemoveCallback, NULL);

    if (uSDHC_CardRemoveCallback != NULL)
    {
        EU_ASSERT(uSDHC_CARD_REMOVE_INT == ((Base->INT_STATUS_EN) & uSDHC_CARD_REMOVE_INT));
        EU_ASSERT(uSDHC_CARD_REMOVE_INT == ((Base->INT_SIGNAL_EN) & uSDHC_CARD_REMOVE_INT));
    }

    /* wait a moment before getting updated present status flags from uSDHC_PRES_STATE register */
    OSIF_TimeDelay(2U);

    /* Verification point: if card detection pin feature is ON, then after initializing, CINST = 0 if no card due to DAT3 card detection is true */
    Tg_uSDHC_PresentStatus = uSDHC_DRV_GetPresentStatusFlags(INST_USDHC1);
    EU_ASSERT(T_uSDHC_CARD_REMOVED == ((Tg_uSDHC_PresentStatus & uSDHC_CARD_INSERTED) >>
                                                   uSDHC_PRES_STATE_CINST_SHIFT));

    /* Verification point: interrupt of card removal occurred */
    EU_ASSERT(uSDHC_PS_STATE_NO_CARD == g_usdhcPresenceStatus);

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
}

#ifdef __cplusplus
}
#endif

/** @} */
