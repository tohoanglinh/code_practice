/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0805.c
*
*   @brief   Test case 0805.
*   @details Function test case 0805.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0805.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0805
* @brief          Check functionality of Card Detection using pin DAT3.
* @details        This test case checks DAT3 Pin functionality as Card Detection.
* @pre            SD card
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly with DAT3 detection true
*                     -# Get present status flags by invoking uSDHC_DRV_GetPresentStatusFlags
*                     -# Verification point:
*                        - In register PROT_CTRL, CINST bit is toggled to 1 which indicates card insertion state.
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_013_001, uSDHC_002_001, uSDHC_021_001, uSDHC_020_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0805(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* Initialize uSDHC module with configuration 0 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_ON == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);

    /* Verification point: if card detection pin feature is ON, then after initializing, CINST = 1 because card is available */
    Tg_uSDHC_PresentStatus = uSDHC_DRV_GetPresentStatusFlags(INST_USDHC1);
    EU_ASSERT(T_uSDHC_CARD_INSERTED == ((Tg_uSDHC_PresentStatus & uSDHC_CARD_INSERTED) >>
                                         uSDHC_PRES_STATE_CINST_SHIFT));

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
}

#ifdef __cplusplus
}
#endif

/** @} */
