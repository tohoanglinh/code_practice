/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0902.c
*
*   @brief   Test case 0902.
*   @details Function test case 0902.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0902.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0902
* @brief          Check functionality of uSDHC_DRV_GetDefaultConfig.
* @details        This test case checks functional of uSDHC_DRV_GetDefaultConfig.
* @pre            There is no card in socket.
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init with configuration 0
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly according to configuration 0
*                     -# Call the uSDHC_DRV_GetDefaultConfig function and store the returned
*                        default configuration into a temporary variable.
*                     -# Verification point: The function gets the correct default configuration structure,
*                        with the following settings:
*                        - DAT3 pin is not used as a card detection pin
*                        - Little endian mode
*                        - No DMA, use interrupt or polling method for transferring
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init with configuration which
*                        was saved in the above temporary configuration structure variable
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly according to the default configuration
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_006_001,
*                 uSDHC_007_001, uSDHC_019_001, uSDHC_019_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0902(void)
{
    /* Local variable */
    usdhc_config_t T_Get_Config;
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* Initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_NO == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Get the default configuration structure */
    uSDHC_DRV_GetDefaultConfig(&T_Get_Config);

    /* Verification point:
        - DAT3 pin is not used as a card detection pin
        - No DMA, use interrupt or polling method for transferring
        - Little endian mode    */
    EU_ASSERT(false == T_Get_Config.cardDetectDat3);
    EU_ASSERT(uSDHC_DMA_MODE_NO == T_Get_Config.dmaMode);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == T_Get_Config.endianMode);

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Initialize uSDHC module again with default configuration */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &T_Get_Config);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_NO == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
}

#ifdef __cplusplus
}
#endif

/** @} */
