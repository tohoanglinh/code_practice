/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0804.c
*
*   @brief   Test case 0804.
*   @details Function test case 0804.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0804.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0804
* @brief          Check functionality of uSDHC_DRV_EnableCardControl.
* @details        This test case checks functional of uSDHC_DRV_EnableCardControl.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification point: Function returns STATUS_SUCCESS
*                     -# Enable wakeup event in low power mode
*                     -# Enable stopping at block gap
*                     -# Enable read wait feature (SDIO card only) at block gap
*                     -# Verification points:
*                        - The correspond wakeup bits are configured correctly
*                        - The correspond stop at block gap request bits are configured correctly
*                        - The correspond 'read wait' bits are configured correctly
*                     -# Disable stopping at block gap
*                     -# Enable continuing request from block gap
*                     -# Disable read wait feature (SDIO card only) at block gap
*                     -# Disable wakeup event in low power mode
*                     -# Verification points:
*                        - The correspond stop at block gap request bits are cleared correctly
*                        - The correspond continue request from block gap bit is set correctly
*                        - The correspond 'read wait' bits are cleared correctly
*                        - The correspond wakeup bits are cleared correctly
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point: Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_009_001, uSDHC_030_001, uSDHC_030_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0804(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];
    bool t_CREQ = true;
    uint32_t t_CREQtimeout = 100U;

    /* Initialize the uSDHC peripheral */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Enable wakeup event in low power mode */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_WAKEUP_ON_CARD_INT | uSDHC_WAKEUP_ON_CARD_INSERT | uSDHC_WAKEUP_ON_CARD_REMOVE,
                                true);

    /* Enable stopping at block gap */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_STOP_AT_BLOCK_GAP | uSDHC_INT_AT_BLOCK_GAP,
                                true);

    /* Enable read wait feature (SDIO card only) at block gap */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_READ_WAIT_CONTROL | uSDHC_NON_EXACT_BLOCK_READ,
                                true);

    /* Verification point: The correspond wakeup bits are configured correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECINT_MASK) >> \
                                         uSDHC_PROT_CTRL_WECINT_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECINS_MASK) >> \
                                         uSDHC_PROT_CTRL_WECINS_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECRM_MASK) >> \
                                         uSDHC_PROT_CTRL_WECRM_SHIFT);

    /* Verification point: The correspond stop at block gap request bits are configured correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_SABGREQ_MASK) >> \
                                         uSDHC_PROT_CTRL_SABGREQ_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_IABG_MASK) >> \
                                         uSDHC_PROT_CTRL_IABG_SHIFT);

    /* Verification point: The correspond 'read wait' bits are configured correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_RWCTL_MASK) >> \
                                         uSDHC_PROT_CTRL_RWCTL_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_NON_EXACT_BLK_RD_MASK) >> \
                                         uSDHC_PROT_CTRL_NON_EXACT_BLK_RD_SHIFT);

    /* Disable stopping at block gap */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_STOP_AT_BLOCK_GAP | uSDHC_INT_AT_BLOCK_GAP,
                                false);

    /* Enable continuing request from block gap */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_CONTINUE_REQUEST,
                                true);

    /* Verification point: The correspond continue request bit is set correctly */
    while((t_CREQ) || (t_CREQtimeout-- > 0U))
    {
        /* continuously scan for CREQ bit in PROT_CTRL */
        if(T_uSDHC_CARD_CONTROL_ENABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_CREQ_MASK) >> \
                                           uSDHC_PROT_CTRL_CREQ_SHIFT)
        {
            t_CREQ = false;
        }
    }

    EU_ASSERT(false == t_CREQ);
    EU_ASSERT(0U < t_CREQtimeout);

    /* Disable read wait feature (SDIO card only) at block gap */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_READ_WAIT_CONTROL | uSDHC_NON_EXACT_BLOCK_READ,
                                false);

    /* Disable wakeup event in low power mode */
    uSDHC_DRV_EnableCardControl(INST_USDHC1,
                                uSDHC_WAKEUP_ON_CARD_INT | uSDHC_WAKEUP_ON_CARD_INSERT | uSDHC_WAKEUP_ON_CARD_REMOVE,
                                false);

    /* Verification point: The correspond wakeup bits are cleared correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECINT_MASK) >> \
                                           uSDHC_PROT_CTRL_WECINT_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECINS_MASK) >>  \
                                           uSDHC_PROT_CTRL_WECINS_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_WECRM_MASK) >>  \
                                           uSDHC_PROT_CTRL_WECRM_SHIFT);

    /* Verification point: The correspond stop at block gap request bits are cleared correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_SABGREQ_MASK) >> \
                                         uSDHC_PROT_CTRL_SABGREQ_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_IABG_MASK) >> \
                                         uSDHC_PROT_CTRL_IABG_SHIFT);

    /* Verification point: The correspond 'read wait' bits are cleared correctly */
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_RWCTL_MASK) >> \
                                         uSDHC_PROT_CTRL_RWCTL_SHIFT);
    EU_ASSERT(T_uSDHC_CARD_CONTROL_DISABLED == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_NON_EXACT_BLK_RD_MASK) >> \
                                         uSDHC_PROT_CTRL_NON_EXACT_BLK_RD_SHIFT);

    /* De-initialize the uSDHC peripheral */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
}

#ifdef __cplusplus
}
#endif

/** @} */
