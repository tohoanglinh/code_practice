/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0904.c
*
*   @brief   Test case 0904.
*   @details Function test case 0904.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0904.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0904
* @brief          Check functionality of uSDHC_DRV_GetCapability.
* @details        This test case checks functional of uSDHC_DRV_GetCapability.
* @pre            There is no card in socket.
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification point: Function returns STATUS_SUCCESS
*                     -# Call the uSDHC_DRV_GetCapability function and store the returned
*                        capability of uSDHC module into a temporary variable
*                     -# Verification points:
*                        - Specification Version Number is SD Host Specification Version 3.0,
*                        supports Test Event Register and ADMA
*                        - Vendor Version Number: NXP uSDHC Version 1.1
*                        - Max Block Length: 4096 bytes
*                        - Maximum block count: 0xFFFFU
*                        - Host controller capabilities flag: Support ADMA, high-speed, DMA,
*                        suspend/resume, voltage 1.8V, voltage 3.0V, voltage 3.3V.
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point: Function returns STATUS_SUCCESS
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_024_001, uSDHC_024_002,
*                 uSDHC_003_001, uSDHC_017_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0904(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    usdhc_capability_t T_Get_Capability;

    /* Initialize the uSDHC peripheral */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config0);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Get the capability of uSDHC module */
    uSDHC_DRV_GetCapability(INST_USDHC1, &T_Get_Capability);

    /* Verification points:
        - Specification Version Number is SD Host Specification Version 3.0,
        supports Test Event Register and ADMA
        - Vendor Version Number: NXP uSDHC Version 1.1
        - Max Block Length: 4096 bytes
        - Maximum block count: 0xFFFFU
        - Host controller capabilities flag: Support ADMA, high-speed, DMA,
        suspend/resume, voltage 1.8V, voltage 3.0V, voltage 3.3V, 4-bit, 8-bit */
    EU_ASSERT(T_uSDHC_SPEC_VERSION == T_Get_Capability.specVersion);
    EU_ASSERT(T_uSDHC_VENDOR_VERSION == T_Get_Capability.vendorVersion);
    EU_ASSERT(T_uSDHC_MAX_BLOCK_LENGTH == T_Get_Capability.maxBlockLength);
    EU_ASSERT(T_uSDHC_MAX_BLOCK_COUNT == T_Get_Capability.maxBlockCount);
    EU_ASSERT(uSDHC_SUPPORT_ADMA == (uSDHC_SUPPORT_ADMA & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_HIGH_SPEED == (uSDHC_SUPPORT_HIGH_SPEED & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_DMA == (uSDHC_SUPPORT_DMA & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_SUSPEND_RESUME == (uSDHC_SUPPORT_SUSPEND_RESUME & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_1V8 == (uSDHC_SUPPORT_1V8 & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_3V0 == (uSDHC_SUPPORT_3V0 & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_3V3 == (uSDHC_SUPPORT_3V3 & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_4BIT == (uSDHC_SUPPORT_4BIT & T_Get_Capability.flags));
    EU_ASSERT(uSDHC_SUPPORT_8BIT == (uSDHC_SUPPORT_8BIT & T_Get_Capability.flags));

    /* De-initialize the uSDHC peripheral */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

}

#ifdef __cplusplus
}
#endif

/** @} */
