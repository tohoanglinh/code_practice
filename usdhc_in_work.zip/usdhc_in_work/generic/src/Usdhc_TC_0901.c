/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0901.c
*
*   @brief   Test case 0901.
*   @details Function test case 0901.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0901.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0901
* @brief          Check functionality of uSDHC_DRV_Init with multiple configurations.
* @details        This test case checks functional of uSDHC_DRV_Init with respect to multiple configurations.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init with configuration 1
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly according to configuration 1.
*                     -# Re-initialize the uSDHC module by calling uSDHC_DRV_Init from configuration 2 till configuration 8
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly according to each configuration 2 to 8.
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_006_001, uSDHC_007_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0901(void)
{
    /* Local variable */
    status_t T_uSDHC_Status;
    uSDHC_Type * Base = Tg_uSDHC_Bases[INST_USDHC1];

    /* Initialize uSDHC module with configuration 1 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_HALF_WORD_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_NO == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 2 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config2);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_NO == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 3 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config3);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA1 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 4 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config4);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_HALF_WORD_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA1 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 5 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config5);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_OFF == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA1 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 6 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config6);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_ON == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA2 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 7 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config7);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_ON == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_HALF_WORD_BIG == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA2 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* Initialize uSDHC module with configuration 8 */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1,
                                    &usdhc1_State,
                                    &usdhc1_Config8);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: uSDHC protocol configuration is setup correctly */
    EU_ASSERT(T_uSDHC_DAT3_CARD_DETECTION_PIN_ON == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_D3CD_MASK) >>\
                                                   uSDHC_PROT_CTRL_D3CD_SHIFT);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_EMODE_MASK)\
                                                    >> uSDHC_PROT_CTRL_EMODE_SHIFT);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA2 == ((Base->PROT_CTRL) & uSDHC_PROT_CTRL_DMASEL_MASK) >> \
                                                   uSDHC_PROT_CTRL_DMASEL_SHIFT);

    /* De-initialize uSDHC module */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);

    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);
}

#ifdef __cplusplus
}
#endif

/** @} */
