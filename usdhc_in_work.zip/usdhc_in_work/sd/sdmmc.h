/*****************************************************************************/
/* FILE NAME: sdmmc.h COPYRIGHT (c) NXP Semiconductors 2017                  */
/*                                                      All Rights Reserved  */
/* DESCRIPTION: SD implementation                                            */
/*                                                                           */
/*****************************************************************************/
/* REV      AUTHOR              DATE        DESCRIPTION OF CHANGE            */
/* ---   -----------          ----------    ---------------------            */
/*****************************************************************************/

/*
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef SD_SDMMC_H
#define SD_SDMMC_H

#include "sd/card.h"

/*!
 * @addtogroup SD_SDMMC
 * @{
 */

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @brief Maximum loop count to check the card operation voltage range */
#define FSL_SDMMC_MAX_VOLTAGE_RETRIES (1000U)

/*! @brief Maximum loop count to check the SDHC card for cmd55 */
#define SDHC_MAX_RETRIES (10)

/*************************************************************************************************
 * API
 ************************************************************************************************/
#if defined(__cplusplus)
extern "C" {
#endif

/*!
 * @name SDMMC Function
 * @{
 */

/*!
 * @brief Select the card to put it into transfer state.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @param relativeAddress Relative address.
 * @param isSelected True to put card into transfer state.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_SelectCard(uint32_t instance,
                          usdhc_transfer_function_t transfer,
                          uint32_t relativeAddress,
                          bool isSelected);

/*!
 * @brief Wait write process complete.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @param relativeAddress Card relative address.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_WaitWriteComplete(uint32_t instance, usdhc_transfer_function_t transfer, uint32_t relativeAddress);

/*!
 * @brief Send application command.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @param relativeAddress Card relative address.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_SDMMC_CardNotSupport Card doesn't support.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_SendApplicationCommand(uint32_t instance, usdhc_transfer_function_t transfer, uint32_t relativeAddress);

/*!
 * @brief Set block count.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @param blockCount Block count.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_SetBlockCount(uint32_t instance, usdhc_transfer_function_t transfer, uint32_t blockCount);

/*!
 * @brief Set the card to be idle state.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_GoIdle(uint32_t instance, usdhc_transfer_function_t transfer);

/*!
 * @brief Stop transfer in multiple block read/write transaction.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_StopTransmission(uint32_t instance, usdhc_transfer_function_t transfer);

/*!
 * @brief Set data block size.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @param blockSize Block size.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_SetBlockSize(uint32_t instance, usdhc_transfer_function_t transfer, uint32_t blockSize);

/*!
 * @brief Switch voltage to low/high.
 *
 * @param base SDHC peripheral base address.
 * @param transfer SDHC transfer function.
 * @retval aStatus_SDMMC_TransferFailed Transfer failed.
 * @retval aStatus_Success Operate successfully.
 */
common_status_t SDMMC_SwitchVoltage(uint32_t instance, usdhc_transfer_function_t transfer);

#if defined(__cplusplus)
}
#endif
/*! @} */

#endif /* SD_SDMMC_H */
