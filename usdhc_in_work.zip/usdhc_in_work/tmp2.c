
/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_TransferBlockingFunction
 * Description   : Transfer data using uSDHC_DRV_TransferBlocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferNonBlockingFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t stdRet = STATUS_SUCCESS;
    g_usdhcTransferComplete = uSDHC_TC_STATE_ERROR;

    do
    {
        stdRet = uSDHC_DRV_Transfer(instance, transfer);
        if (STATUS_SUCCESS != stdRet)
        {
            stdRet = STATUS_ERROR;
        }
        else
        {
            stdRet = OSIF_SemaWait(&g_TransferCompleteSem, T_uSDHC_TIMEOUT);
            if (STATUS_TIMEOUT == stdRet)
            {
                stdRet = STATUS_ERROR;
            }
        }
        /* Report generic error on transfer complete failure. */
        if(uSDHC_TC_STATE_ERROR == g_usdhcTransferComplete)
        {
            stdRet = STATUS_ERROR;
        }
    } while (STATUS_BUSY == stdRet);

    return stdRet;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_TransferBlockingFunction
 * Description   : Transfer data using uSDHC_DRV_TransferBlocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferBlockingFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t stdRet = STATUS_SUCCESS;
    g_usdhcTransferComplete = uSDHC_TC_STATE_ERROR;

    do
    {
        stdRet = uSDHC_DRV_TransferBlocking(instance, transfer, T_uSDHC_TIMEOUT);
        if (STATUS_SUCCESS != stdRet)
        {
            stdRet = STATUS_ERROR;
        }
        else
        {
            /* Waiting for TransferComplete callback. */
            usdhc1_State.transferCallback(instance, 0U, usdhc1_State.transferCallbackParam);
            if (STATUS_TIMEOUT == stdRet)
            {
                stdRet = STATUS_ERROR;
            }
        }
        /* Report generic error on transfer complete failure. */
        if(uSDHC_TC_STATE_ERROR == g_usdhcTransferComplete)
        {
            stdRet = STATUS_ERROR;
        }
    } while (STATUS_BUSY == stdRet);

    return stdRet;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_TransferCompleteCallbackMod
 * Description   : A modified version of callback function for
 *                 Transfer Complete event for interrupt test purpose.
 *
 *END**************************************************************************/
void T_uSDHC_TransferCompleteCallbackMod(uint32_t instance, uint32_t status, void *userData)
{
    (void)instance;
    (void)userData;
    if((uint32_t)STATUS_SUCCESS == status)
    {
        /* Transfer done */
        g_usdhcTransferComplete = uSDHC_TC_STATE_DONE;
    }
    else
    {
        /* Transfer error */
        g_usdhcTransferComplete = uSDHC_TC_STATE_ERROR;
    }

    /* identify which interrupt has been triggered */
    T_uSDHC_CheckInterrupt(instance);

    (void)OSIF_SemaPost(&g_TransferCompleteSem);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_CardInterruptCallback
 * Description   : Card interrupt callback function testing example.
 *
 *END**************************************************************************/
void T_uSDHC_CardInterruptCallback(uint32_t instance, uint32_t status, void *userData)
{
    (void)instance;
    (void)userData;

    /* identify which interrupt has been triggered */
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_BlockGapCallback
 * Description   : Block gap callback function testing example.
 *
 *END**************************************************************************/
void T_uSDHC_BlockGapCallback(uint32_t instance, uint32_t status, void *userData)
{
    (void)instance;
    (void)userData;

    /* identify which interrupt has been triggered */
    T_uSDHC_CheckInterrupt(instance);
}