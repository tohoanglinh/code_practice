CHANGE1. S3_HEADER_FILE
#include <stdio.h>