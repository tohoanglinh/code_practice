/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0803.c
*
*   @brief   Test case 0803.
*   @details Function test case 0803.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0803.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0803
* @brief          Check functionality of uSDHC_DRV_SetDataBusWidth.
* @details        This test case checks functional of uSDHC_DRV_SetDataBusWidth.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification point: Function returns STATUS_SUCCESS
*                     -# Set data bus width 1-bit for uSDHC module
*                     -# Verification point: Data Transfer Width bit field is configured correctly
*                     -# Set data bus width 4-bit for uSDHC module
*                     -# Verification point: Data Transfer Width bit field is configured correctly
*                     -# Set data bus width 8-bit for uSDHC module
*                     -# Verification point: Data Transfer Width bit field is configured correctly
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point: Function returns STATUS_SUCCESS
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_005_001, uSDHC_027_001, uSDHC_027_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0803(void)
{
    /* Local variable */
    uSDHC_Type * base = g_usdhcBases[INST_USDHC1];

    /* Initialize uSDHC module */
    (void)uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, &usdhc1_Config0);

    /* Set data bus width for uSDHC module */
    uSDHC_DRV_SetDataBusWidth(INST_USDHC1, uSDHC_DATA_BUS_WIDTH_1BIT);
    /* Verification point: Data Transfer Width bit field is configured correctly */
    EU_ASSERT(uSDHC_DATA_BUS_WIDTH_1BIT == ((base->PROT_CTRL) & uSDHC_PROT_CTRL_DTW_MASK) >> uSDHC_PROT_CTRL_DTW_SHIFT);

    /* Set data bus width for uSDHC module */
    uSDHC_DRV_SetDataBusWidth(INST_USDHC1, uSDHC_DATA_BUS_WIDTH_4BIT);
    /* Verification point: Data Transfer Width bit field is configured correctly */
    EU_ASSERT(uSDHC_DATA_BUS_WIDTH_4BIT == ((base->PROT_CTRL) & uSDHC_PROT_CTRL_DTW_MASK) >> uSDHC_PROT_CTRL_DTW_SHIFT);

    /* Set data bus width for uSDHC module */
    uSDHC_DRV_SetDataBusWidth(INST_USDHC1, uSDHC_DATA_BUS_WIDTH_8BIT);
    /* Verification point: Data Transfer Width bit field is configured correctly */
    EU_ASSERT(uSDHC_DATA_BUS_WIDTH_8BIT == ((base->PROT_CTRL) & uSDHC_PROT_CTRL_DTW_MASK) >> uSDHC_PROT_CTRL_DTW_SHIFT);

    /* De-initialize uSDHC module */
    (void)uSDHC_DRV_Deinit(INST_USDHC1);
}

#ifdef __cplusplus
}
#endif

/** @} */
