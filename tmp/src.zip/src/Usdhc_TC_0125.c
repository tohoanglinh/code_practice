/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0125.c
*
*   @brief   Test case 0125.
*   @details Function test case 0125.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0125.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0125
* @brief          Write Read Erase: a single data blocks (ADMA2/NO_DMA) BlockSize not divisible by 4.
* @details        Write Read Erase: a single data blocks (ADMA2/NO_DMA) BlockSize not divisible by 4.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique WhiteBox
* @test_procedure Steps:
*                     -# Invoke T_uSDHC_Init()
*                     -# Prepare data arrays for write and read sessions
*                     -# Write data to card
*                     -# Verification Point:
*                           - T_uSDHC_WriteData returns STATUS_SUCCESS
*                     -# Read data from card after writing
*                     -# Verification Point:
*                           - T_uSDHC_ReadData returns STATUS_SUCCESS
*                     -# Compare data between read and write after writing
*                     -# Verification point:
*                        - Read data should be matched with Write data
*                     -# Erase data from card
*                     -# Verification Point:
*                           - T_uSDHC_EraseData returns STATUS_SUCCESS
*                     -# Read data from card after erasing
*                     -# Verification Point:
*                           - T_uSDHC_ReadData returns STATUS_SUCCESS
*                     -# Compare data between read and write after erasing
*                        - Read data should be cleared
*                     -# Invoke T_uSDHC_DeInit()
* @pass_criteria  Verification Points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_006_001,
*                 uSDHC_007_001, uSDHC_019_001, uSDHC_019_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0125(void)
{
    /* Local variables */
    status_t T_uSDHC_Status = STATUS_ERROR;
    sd_card_t *card = &t_g_sd;
    uint32_t numBlocks = T_uSDHC_SINGLE_BLOCK;
    uint32_t blockAddress = T_uSDHC_DATA_BLOCK_START;
    uint32_t blockSize = T_uSDHC_DATA_BLOCK_SIZE_INDIVISIBLE_BY_4;
    bool enableACMD12 = false;
    bool blockingMode = true;

    /* INIT MODULE: Initialize uSDHC driver and card */
    T_uSDHC_Init();

    /* PREPARE DATA: Prepare a data array for a write session */
    T_PrepareData(t_g_usdhc_dataWrite, numBlocks*blockSize);

    /* PREPARE DATA: Erase a data array for a read session */
    memset(t_g_usdhc_dataRead, T_CARD_ERASED_DATA, numBlocks*blockSize);

    /* TRANSFER DATA: Write data to card */
    T_uSDHC_Status = T_uSDHC_WriteData(card, t_g_usdhc_dataWrite, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_ERROR == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after writing */
    T_uSDHC_Status = T_uSDHC_ReadData(card, t_g_usdhc_dataRead, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_ERROR == T_uSDHC_Status);

    /* COMPARE DATA: Compare between Read and Write after writing session */
    EU_ASSERT(0U != memcmp(t_g_usdhc_dataRead, t_g_usdhc_dataWrite, numBlocks*blockSize));

    /* TRANSFER DATA: Erase data from card */
    T_uSDHC_Status = T_uSDHC_EraseData(card, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after erasing */
    T_uSDHC_Status = T_uSDHC_ReadData(card, t_g_usdhc_dataRead, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_ERROR == T_uSDHC_Status);

    /* PREPARE DATA: Erase the write data array for a comparing session */
    memset(t_g_usdhc_dataWrite, T_CARD_ERASED_DATA, numBlocks*blockSize);

    /* COMPARE DATA: Compare between Read and Write after erasing session */
    EU_ASSERT(0U == memcmp(t_g_usdhc_dataRead, t_g_usdhc_dataWrite, numBlocks*blockSize));

    /* DEINIT MODULE: De-initialize uSDHC driver and card */
    T_uSDHC_Deinit();

    /* Block if error occurs */
    #if (DEBUG)
    T_uSDHC_DebugErrorInterrupt();
    #endif
}

#ifdef __cplusplus
}
#endif

/** @} */
