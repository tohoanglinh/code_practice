/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0806.c
*
*   @brief   Test case 0806.
*   @details Function test case 0806.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0806.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0806
* @brief          Check functionality of uSDHC_DRV_Reset – Timeout if ipg_per_clk disabled.
* @details        This test case disables ipg_per_clk and calls uSDHC_DRV_Reset, so the RESET bits
*                 (RSTA, RSTD, RSTC) are not self-cleared.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique Blackbox
* @test_procedure Steps:
*                     -# Initialize the uSDHC driver module by calling uSDHC_DRV_Init with configuration 0
*                     -# Initialize clock OSIF to guarantee OSIF_GetMiliseconds() works
*                     -# Gate off ipg_per_clk only (see RM, 49.4.12 System Control)
*                     -# Verification point:
*                        - uSDHC_DRV_Reset function return STATUS_TIMEOUT
*                     -# Deinitialize uSDHC driver by calling uSDHC_DRV_Deinit.
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_022_001, uSDHC_022_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0806(void)
{
    /* Local variable */
    uSDHC_Type * base = g_usdhcBases[INST_USDHC1];

    /* Initialize uSDHC module */
    (void)uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, &usdhc1_Config0);

    /* initialize clock OSIF to guarantee OSIF_GetMilliseconds() works */
    OSIF_TimeDelay(10U);

    /* gate off ipg_per_clk only (see RM, 49.4.12 System Control) */
    base->VEND_SPEC &= ~(uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_MASK);

    /* reset should be timeout due to ipg_clk off */
    EU_ASSERT(STATUS_TIMEOUT == uSDHC_DRV_Reset(INST_USDHC1, uSDHC_RESET_ALL, T_uSDHC_TIMEOUT_MS));

    /* De-initialize uSDHC module */
    (void)uSDHC_DRV_Deinit(INST_USDHC1);
}

#ifdef __cplusplus
}
#endif

/** @} */
