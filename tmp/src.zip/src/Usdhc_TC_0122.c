/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0122.c
*
*   @brief   Test case 0122.
*   @details Function test case 0122.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0122.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0122
* @brief          Write Read Erase: multiple data blocks (ADMA2/NO_DMA) AutoCMD12 disabled.
* @details        Write Read Erase: multiple data blocks (ADMA2/NO_DMA) AutoCMD12 disabled, NON_STOP.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique WhiteBox
* @test_procedure Steps:
*                     -# Invoke T_uSDHC_Init()
*                     -# Prepare data arrays for write and read sessions
*                     -# Write data to card
*                     -# Verification Point:
*                           - T_uSDHC_WriteData returns STATUS_SUCCESS
*                     -# Read data from card after writing
*                     -# Verification Point:
*                           - T_uSDHC_ReadData returns STATUS_SUCCESS
*                     -# Compare data between read and write after writing
*                     -# Verification point:
*                        - Read data should be matched with Write data
*                     -# Erase data from card
*                     -# Verification Point:
*                           - T_uSDHC_EraseData returns STATUS_SUCCESS
*                     -# Read data from card after erasing
*                     -# Verification Point:
*                           - T_uSDHC_ReadData returns STATUS_SUCCESS
*                     -# Compare data between read and write after erasing
*                        - Read data should be cleared
*                     -# Invoke T_uSDHC_DeInit()
* @pass_criteria  Verification Points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_006_001,
*                 uSDHC_007_001, uSDHC_019_001, uSDHC_019_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0122(void)
{
    /* Local variables */
    status_t T_uSDHC_Status = STATUS_ERROR;
    sd_card_t *card = &t_g_sd;
    uint32_t numBlocks = T_uSDHC_MULTI_BLOCKS_MAX;
    uint32_t blockAddress = T_uSDHC_DATA_BLOCK_START;
    uint32_t blockSize = T_uSDHC_DATA_DEFAULT_BLOCK_SIZE;
    bool disableACMD12 = false;
    bool enableACMD12 = true;
    bool blockingMode = true;

    /* INIT MODULE: Initialize uSDHC driver and card */
    T_uSDHC_Init();

    /* reset all interrupt monitor variables */
    T_uSDHC_ResetInterruptMonitor();

    /* PREPARE DATA: Prepare a data array for a write session */
    T_PrepareData(t_g_usdhc_dataWrite, numBlocks*blockSize);

    /* PREPARE DATA: Erase a data array for a read session */
    memset(t_g_usdhc_dataRead, T_CARD_ERASED_DATA, numBlocks*blockSize);

    /* TRANSFER DATA: Write data to card */
    T_uSDHC_Status = T_uSDHC_WriteData(card, t_g_usdhc_dataWrite, disableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after writing */
    T_uSDHC_Status = T_uSDHC_ReadData(card, t_g_usdhc_dataRead, disableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_TIMEOUT == T_uSDHC_Status);

    /* COMPARE DATA: Compare between Read and Write after writing session */
    EU_ASSERT(0U != memcmp(t_g_usdhc_dataRead, t_g_usdhc_dataWrite, numBlocks*blockSize));

    /* get present status as busy due to command/data inhibit, read transfer active of uSDHC */
    EU_ASSERT(uSDHC_COMMAND_INHIBIT == (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & uSDHC_COMMAND_INHIBIT));
    EU_ASSERT(uSDHC_DATA_INHIBIT == (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & uSDHC_DATA_INHIBIT));
    EU_ASSERT(uSDHC_READ_TRANSFER_ACTIVE == (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & uSDHC_READ_TRANSFER_ACTIVE));

    /* wait for data timeout interrupt due to read transfer active */
    while(false == t_g_uSDHC_DATA_TIMEOUT_INT)
    {
    }

    /* reset ALL CMD/DATA line inhibit */
    T_uSDHC_Status = uSDHC_DRV_Reset(INST_USDHC1, uSDHC_RESET_ALL, T_uSDHC_TIMEOUT_MS);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* stop transmission */
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_StopTransmission(card));

    /* TRANSFER DATA: Write data to card */
    T_uSDHC_Status = T_uSDHC_WriteData(card, t_g_usdhc_dataWrite, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after writing */
    T_uSDHC_Status = T_uSDHC_ReadData(card, t_g_usdhc_dataRead, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* COMPARE DATA: Compare between Read and Write after writing session */
    EU_ASSERT(0U == memcmp(t_g_usdhc_dataRead, t_g_usdhc_dataWrite, numBlocks*blockSize));

    /* TRANSFER DATA: Erase data from card */
    T_uSDHC_Status = T_uSDHC_EraseData(card, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* TRANSFER DATA: Read data from card after erasing */
    T_uSDHC_Status = T_uSDHC_ReadData(card, t_g_usdhc_dataRead, enableACMD12, blockSize, numBlocks, blockAddress, blockingMode);
    EU_ASSERT(STATUS_SUCCESS == T_uSDHC_Status);

    /* PREPARE DATA: Erase the write data array for a comparing session */
    memset(t_g_usdhc_dataWrite, T_CARD_ERASED_DATA, numBlocks*blockSize);

    /* COMPARE DATA: Compare between Read and Write after erasing session */
    EU_ASSERT(0U == memcmp(t_g_usdhc_dataRead, t_g_usdhc_dataWrite, numBlocks*blockSize));

    /* DEINIT MODULE: De-initialize uSDHC driver and card */
    T_uSDHC_Deinit();
}

#ifdef __cplusplus
}
#endif

/** @} */
