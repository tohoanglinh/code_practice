/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0900.c
*
*   @brief   Test case 0900.
*   @details Function test case 0900.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0900.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0900
* @brief          Check functionality of uSDHC_DRV_GetDefaultConfig.
* @details        This test case checks functionality of uSDHC_DRV_GetDefaultConfig.
* @pre            There is no card in socket.
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Call the uSDHC_DRV_GetDefaultConfig function and store the returned
*                        default configuration into a temporary variable.
*                     -# Verification point: The function gets the correct default configuration structure,
*                        with the following settings:
*                       - card detection by CD/DAT3 pin is disable.
*                       - transfer method: ADMA2.
*                       - little endian mode.
*                       - table size: 8 bytes.
*                       - extension: NULL.
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_019_001, uSDHC_019_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0900(void)
{
    /* Local variable */
    usdhc_config_t usdhc_config;

    /* Get the default configuration structure */
    uSDHC_DRV_GetDefaultConfig(&usdhc_config);

    /* Verification point:
     - card detection by CD/DAT3 pin is disable.
     - transfer method: ADMA2
     - little endian mode.
     - table size: 8 bytes.
     - extension: NULL.
    */
    EU_ASSERT(false == usdhc_config.cardDetectDat3);
    EU_ASSERT(uSDHC_DMA_MODE_ADMA2 == usdhc_config.dmaMode);
    EU_ASSERT(uSDHC_ENDIAN_MODE_LITTLE == usdhc_config.endianMode);
    EU_ASSERT(uSDHC_DEFAULT_ADMA2_TABLE_SIZE == usdhc_config.admaTableSize);
    EU_ASSERT(NULL == usdhc_config.extension);
}

#ifdef __cplusplus
}
#endif

/** @} */
