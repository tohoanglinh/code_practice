/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file    Usdhc_TC_Common.c
*
*   @brief   Test case common source file
*   @details Test case common source file
*
*   @addtogroup USDHC_TESTS
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_Common.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/



/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/
volatile t_usdhc_tc_state_t t_g_usdhc_transferComplete = T_uSDHC_TC_STATE_ERROR;
volatile uint32_t t_g_usdhc_presentStatus;
sd_card_t t_g_sd;

/* data transfer (write/read) variable and alignment for ADMA1, ADMA2
 * Because: ADMA1 only supports 4KB=4096B aligned data in system memory to transfer
 * Because: ADMA2 supports any location and any size to transfer
 */
#ifdef uSDHC_ENABLE_ADMA1
    ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
    uint8_t t_g_usdhc_dataWriteADMA1[T_uSDHC_DATA_BUFFER_SIZE];

    ALIGNED(uSDHC_ADMA1_ADDRESS_ALIGN)
    uint8_t t_g_usdhc_dataReadADMA1[T_uSDHC_DATA_BUFFER_SIZE];
#else
    ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
    uint8_t t_g_usdhc_dataWrite[T_uSDHC_DATA_BUFFER_SIZE];

    ALIGNED(uSDHC_ADMA2_ADDRESS_ALIGN)
    uint8_t t_g_usdhc_dataRead[T_uSDHC_DATA_BUFFER_SIZE];
#endif /* uSDHC_ENABLE_ADMA1 */

bool t_g_uSDHC_COMMAND_COMPLETE_INT = false;
bool t_g_uSDHC_DATA_COMPLETE_INT = false;
bool t_g_uSDHC_BLOCK_GAP_INT = false;
bool t_g_uSDHC_DMA_COMPLETE_INT = false;
bool t_g_uSDHC_BUFFER_WRITE_READY_INT = false;
bool t_g_uSDHC_BUFFER_READ_READY_INT = false;
bool t_g_uSDHC_CARD_INSERT_INT = false;
bool t_g_uSDHC_CARD_REMOVE_INT = false;
bool t_g_uSDHC_CARD_INTERRUPT_INT = false;
bool t_g_uSDHC_COMMAND_TIMEOUT_INT = false;
bool t_g_uSDHC_COMMAND_CRC_ERROR_INT = false;
bool t_g_uSDHC_COMMAND_ENDBIT_ERROR_INT = false;
bool t_g_uSDHC_COMMAND_INDEX_ERROR_INT = false;
bool t_g_uSDHC_DATA_TIMEOUT_INT = false;
bool t_g_uSDHC_DATA_CRC_ERROR_INT = false;
bool t_g_uSDHC_DATA_ENDBIT_ERROR_INT = false;
bool t_g_uSDHC_AUTO_CMD12_ERROR_INT = false;
bool t_g_uSDHC_DMA_ERROR_INT = false;

/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
static void T_uSDHC_CheckInterrupt(uint32_t instance);
static bool T_uSDHC_IsCardPresent(sd_card_t *card);
static bool T_uSDHC_IsCardWriteProtected(sd_card_t *card);
static void T_uSDHC_WaitCardBuffer(uint32_t instance);

/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*FUNCTION**********************************************************************
 *
 * Function Name : uSDHC_CheckInterrupt
 * Description   : Check what type of interrupt has been occurred.
 *
 *END**************************************************************************/
static void T_uSDHC_CheckInterrupt(uint32_t instance)
{
    uSDHC_Type * base = g_usdhcBases[instance];

    uint32_t interruptFlags = 0U;
    interruptFlags = uSDHC_GetInterruptStatusFlags(base);

    if ((interruptFlags & uSDHC_COMMAND_COMPLETE_INT) != 0U)
    {
        t_g_uSDHC_COMMAND_COMPLETE_INT = true;
    }

    if ((interruptFlags & uSDHC_DATA_COMPLETE_INT) != 0U)
    {
        t_g_uSDHC_DATA_COMPLETE_INT = true;
    }

    if ((interruptFlags & uSDHC_BLOCK_GAP_INT) != 0U)
    {
        t_g_uSDHC_BLOCK_GAP_INT = true;
    }

    if ((interruptFlags & uSDHC_DMA_COMPLETE_INT) != 0U)
    {
        t_g_uSDHC_DMA_COMPLETE_INT = true;
    }

    if ((interruptFlags & uSDHC_BUFFER_WRITE_READY_INT) != 0U)
    {
        t_g_uSDHC_BUFFER_WRITE_READY_INT = true;
    }

    if ((interruptFlags & uSDHC_BUFFER_READ_READY_INT) != 0U)
    {
        t_g_uSDHC_BUFFER_READ_READY_INT = true;
    }

    if ((interruptFlags & uSDHC_CARD_INSERT_INT) != 0U)
    {
        t_g_uSDHC_CARD_INSERT_INT = true;
    }

    if ((interruptFlags & uSDHC_CARD_REMOVE_INT) != 0U)
    {
        t_g_uSDHC_CARD_REMOVE_INT = true;
    }

    if ((interruptFlags & uSDHC_CARD_INTERRUPT_INT) != 0U)
    {
        t_g_uSDHC_CARD_INTERRUPT_INT = true;
    }

    if ((interruptFlags & uSDHC_COMMAND_TIMEOUT_INT) != 0U)
    {
        t_g_uSDHC_COMMAND_TIMEOUT_INT = true;
    }

    if ((interruptFlags & uSDHC_COMMAND_CRC_ERROR_INT) != 0U)
    {
        t_g_uSDHC_COMMAND_CRC_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_COMMAND_ENDBIT_ERROR_INT) != 0U)
    {
        t_g_uSDHC_COMMAND_ENDBIT_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_COMMAND_INDEX_ERROR_INT) != 0U)
    {
        t_g_uSDHC_COMMAND_INDEX_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_DATA_TIMEOUT_INT) != 0U)
    {
        t_g_uSDHC_DATA_TIMEOUT_INT = true;
    }

    if ((interruptFlags & uSDHC_DATA_CRC_ERROR_INT) != 0U)
    {
        t_g_uSDHC_DATA_CRC_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_DATA_ENDBIT_ERROR_INT) != 0U)
    {
        t_g_uSDHC_DATA_ENDBIT_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_AUTO_CMD12_ERROR_INT) != 0U)
    {
        t_g_uSDHC_AUTO_CMD12_ERROR_INT = true;
    }

    if ((interruptFlags & uSDHC_DMA_ERROR_INT) != 0U)
    {
        t_g_uSDHC_DMA_ERROR_INT = true;
    }
}

/* pre: setup DAT3 (pulldown) or CD pin to detect card presence */
static bool T_uSDHC_IsCardPresent(sd_card_t *card)
{
    bool cardPresence = false;

    if ((NULL != card) && (0U != (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & (uint32_t)uSDHC_CARD_INSERTED)))
    {
        cardPresence = true;
    }

    return cardPresence;
}

/* pre: setup WP pin to detect write protect */
static bool T_uSDHC_IsCardWriteProtected(sd_card_t *card)
{
    bool cardWriteProtect = false;

    if ((NULL != card) && (0U == (uSDHC_DRV_GetPresentStatusFlags(card->host.instance) & (uint32_t)uSDHC_WRITE_PROTECTED)))
    {
        cardWriteProtect = true;
    }

    return cardWriteProtect;
}

/* Wait for the card's buffer to be not full to write to improve the write performance.
 * This is done by polling DAT0 line level, checking busy state.
 */
static void T_uSDHC_WaitCardBuffer(uint32_t instance)
{
    while (!(uSDHC_DRV_GetPresentStatusFlags(instance) & uSDHC_DATA0_LINE_LEVEL))
    {
    }
}

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*FUNCTION**********************************************************************
 *
 * Function Name : T_CheckDevError
 * Description   : Check a development error should be detected with invalid configurations.
 *
 *END**************************************************************************/
void T_CheckDevError(void)
{
    /* check if Dev_ErrorId has been toggled due to error */
    EU_ASSERT(Dev_ErrorId == 1);

    /* clear Dev_ErrorId */
    Dev_ErrorId = 0;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_PrepareData
 * Description   : Prepare data for writing.
 *
 *END**************************************************************************/
void T_PrepareData(uint8_t * data, uint32_t size)
{
    uint32_t i = 0U;

    for (i = 0U; i < size; i++)
    {
        data[i] = (uint8_t)i;
    }
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_ResetInterruptMonitor
 * Description   : Reset all interrupt monitors (array) before execute a test case.
 *
 *END**************************************************************************/
void T_uSDHC_ResetInterruptMonitor(void)
{
    t_g_uSDHC_COMMAND_COMPLETE_INT = false;
    t_g_uSDHC_DATA_COMPLETE_INT = false;
    t_g_uSDHC_BLOCK_GAP_INT = false;
    t_g_uSDHC_DMA_COMPLETE_INT = false;
    t_g_uSDHC_BUFFER_WRITE_READY_INT = false;
    t_g_uSDHC_BUFFER_READ_READY_INT = false;
    t_g_uSDHC_CARD_INSERT_INT = false;
    t_g_uSDHC_CARD_REMOVE_INT = false;
    t_g_uSDHC_CARD_INTERRUPT_INT = false;
    t_g_uSDHC_COMMAND_TIMEOUT_INT = false;
    t_g_uSDHC_COMMAND_CRC_ERROR_INT = false;
    t_g_uSDHC_COMMAND_ENDBIT_ERROR_INT = false;
    t_g_uSDHC_COMMAND_INDEX_ERROR_INT = false;
    t_g_uSDHC_DATA_TIMEOUT_INT = false;
    t_g_uSDHC_DATA_CRC_ERROR_INT = false;
    t_g_uSDHC_DATA_ENDBIT_ERROR_INT = false;
    t_g_uSDHC_AUTO_CMD12_ERROR_INT = false;
    t_g_uSDHC_DMA_ERROR_INT = false;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_DebugErrorInterrupt
 * Description   : Debug all interrupts except known command timeout (SD_Init).
 *
 *END**************************************************************************/
void T_uSDHC_DebugErrorInterrupt(void)
{
    while(
         (true == t_g_uSDHC_COMMAND_CRC_ERROR_INT) ||
         (true == t_g_uSDHC_COMMAND_ENDBIT_ERROR_INT) ||
         (true == t_g_uSDHC_COMMAND_INDEX_ERROR_INT) ||
         (true == t_g_uSDHC_DATA_TIMEOUT_INT) ||
         (true == t_g_uSDHC_DATA_CRC_ERROR_INT) ||
         (true == t_g_uSDHC_DATA_ENDBIT_ERROR_INT) ||
         (true == t_g_uSDHC_AUTO_CMD12_ERROR_INT) ||
         (true == t_g_uSDHC_DMA_ERROR_INT)
         )
    {
    }
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_Init
 * Description   : Initialize usdhc host and card
 *                 STATUS_SUCCESS: init success
 *                 STATUS_ERROR: init fail, or no card, or SD_Init fails
 *
 *END**************************************************************************/
status_t T_uSDHC_Init(void)
{
    status_t status = STATUS_ERROR;
    usdhc_config_t *usdhc_config = &usdhc1_Config0;
    sd_card_t *card = &t_g_sd;

    /* clear card pointer */
    memset(card, 0U, sizeof(sd_card_t));

    /* init usdhc host driver */
    status = uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, usdhc_config);
    if (STATUS_SUCCESS == status)           /* if init usdhc host driver successfully */
    {
        /* install callback functions */
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, T_uSDHC_TransferCompleteCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, T_uSDHC_CardInsertCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, T_uSDHC_CardRemoveCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, T_uSDHC_BlockGapCallback, NULL);
        uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, T_uSDHC_CardInterruptCallback, NULL);

        /* save host information to card, must do before sd_init */
        card->host.instance = INST_USDHC1;
        card->host.config.endianMode = usdhc_config->endianMode;
        card->host.config.dmaMode = usdhc_config->dmaMode;
        card->host.config.admaTable = usdhc_config->admaTable;
        card->host.config.admaTableSize = usdhc_config->admaTableSize;
        card->host.config.cardDetectDat3 = false;                          /* card detection isn't supported in SD layer */
        card->host.transfer = T_uSDHC_TransferBlockingFunction;

        if (true == T_uSDHC_IsCardPresent(card))                /* if a card is present, init the card */
        {
            status = (status_t)SD_Init(card);
        }
        else            /* if no card, report error */
        {
            status = STATUS_ERROR;
        }

        /* DAT3 does not monitor card insertion */
        g_usdhcBases[INST_USDHC1]->PROT_CTRL &= ~(uint32_t)uSDHC_PROT_CTRL_D3CD_MASK;
    }

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_Deinit
 * Description   : De-Initialize uSDHC host and card
 *                 STATUS_SUCCESS: deinit success
 *                 STATUS_ERROR: no card, or SD_DeInit fails, or reset timeout
 *
 *END**************************************************************************/
status_t T_uSDHC_Deinit(void)
{
    status_t status = STATUS_ERROR;
    sd_card_t *card = &t_g_sd;

    if (true == T_uSDHC_IsCardPresent(card))
    {
        /* deinit card */
        status = (status_t)SD_DeInit(card);
        if (STATUS_SUCCESS == status)
        {
            /* deinstall callback functions */
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_TRANSFER_COMPLETE, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INSERT, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_REMOVE, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_BLOCK_GAP, NULL, NULL);
            uSDHC_DRV_InstallCallback(INST_USDHC1, uSDHC_EVENT_CARD_INTERRUPT, NULL, NULL);

            /* deinit uSDHC host driver */
            status = uSDHC_DRV_Deinit(INST_USDHC1);
            if (STATUS_SUCCESS == status)
            {
                /* reset uSDHC host driver */
                status = uSDHC_DRV_Reset(INST_USDHC1, uSDHC_RESET_ALL, T_uSDHC_TIMEOUT_MS);
            }
        }
    }

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferBlockingFunction
 * Description   : Transfer data using uSDHC_DRV_TransferBlocking function, blocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferBlockingFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t status = STATUS_ERROR;
    uint32_t transfer_busy_retries = 5U;

    do
    {
        transfer_busy_retries--;
        status = uSDHC_DRV_TransferBlocking(instance, transfer, T_uSDHC_TIMEOUT_MS);
    } while ((STATUS_BUSY == status) && (transfer_busy_retries > 0U));

    return status;
}


/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferFunction
 * Description   : Transfer data using uSDHC_DRV_Transfer function, non-blocking mode.
 *
 *END**************************************************************************/
status_t T_uSDHC_TransferFunction(uint32_t instance, usdhc_transfer_t * transfer)
{
    status_t status = STATUS_ERROR;
    uint32_t transfer_busy_retries = 5U;
    uint32_t timeout = T_uSDHC_TIMEOUT_MS;

    do
    {
        transfer_busy_retries--;
        status = uSDHC_DRV_Transfer(instance, transfer);
    } while ((STATUS_BUSY == status) && (transfer_busy_retries > 0U));

    if (usdhc1_State.transferCallback != NULL)
    {
        while ((T_uSDHC_TC_STATE_DONE != t_g_usdhc_transferComplete) && (timeout > 0U))
        {
            /* wait for transfer complete status or until timeout */
            timeout--;
            OSIF_TimeDelay(1U);
        }

        /* update transfer complete variable */
        t_g_usdhc_transferComplete = T_uSDHC_TC_STATE_ERROR;

        if (timeout == 0U)
        {
            status = STATUS_TIMEOUT;
        }
    }

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_TransferCompleteCallback
 * Description   : Transfer complete callback function.
 *
 *END**************************************************************************/
void T_uSDHC_TransferCompleteCallback(uint32_t instance, uint32_t status, void *userData)
{
    if((uint32_t)STATUS_SUCCESS == status)
    {
        /* transfer complete success */
        t_g_usdhc_transferComplete = T_uSDHC_TC_STATE_DONE;
    }
    else
    {
        t_g_usdhc_transferComplete = T_uSDHC_TC_STATE_ERROR;
    }
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardInsertCallback
 * Description   : Card insert callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardInsertCallback(uint32_t instance, uint32_t status, void *userData)
{
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardRemoveCallback
 * Description   : Card remove callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardRemoveCallback(uint32_t instance, uint32_t status, void *userData)
{
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_BlockGapCallback
 * Description   : Block gap callback function.
 *
 *END**************************************************************************/
void T_uSDHC_BlockGapCallback(uint32_t instance, uint32_t status, void *userData)
{
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_CardInterruptCallback
 * Description   : Card interrupt callback function.
 *
 *END**************************************************************************/
void T_uSDHC_CardInterruptCallback(uint32_t instance, uint32_t status, void *userData)
{
    T_uSDHC_CheckInterrupt(instance);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_WriteData
 * Description   : write data to card.
 *
 *END**************************************************************************/
status_t T_uSDHC_WriteData(sd_card_t *card,
                     const uint8_t *txBuffer,
                           bool acmd12,
                           uint32_t blockSize,
                           uint32_t blockCount,
                           uint32_t blockAddress,
                           bool blockingMode)
{
    /* WRITE DATA TO CARD
     * - Check ReadOnly Card
     * - Wait for card's buffer not full to write to improve write performance
     * - Wait last write complete
     * - Send Write CMD
     */
    status_t writeStatus = STATUS_ERROR;
    usdhc_transfer_t content = {0};
    usdhc_command_t command = {0};
    usdhc_data_t data = {0};

    if (true == T_uSDHC_IsCardWriteProtected(card))
    {
        writeStatus = STATUS_ERROR;
    }
    else
    {
        T_uSDHC_WaitCardBuffer(card->host.instance);

        /* send CMD13 SEND_STATUS to request card sends its status register, wait last write complete */
        writeStatus == SDMMC_WaitWriteComplete(card->host.instance, card->host.transfer, card->relativeAddress);

        /* configure data */
        data.enableAutoCMD12 = acmd12;
        data.blockSize = blockSize;
        data.blockCount = blockCount;
        data.txData = (const uint32_t *)txBuffer;

        /* configure command */
        command.index = aSDMMC_WriteSingleBlock;
        if (data.blockCount > 1U)
        {
            command.index = aSDMMC_WriteMultipleBlock;
        }
        command.argument = blockAddress;
        command.responseType = uSDHC_RESPONSE_TYPE_R1;
        if (true == data.enableAutoCMD12)
        {
            command.responseType = uSDHC_RESPONSE_TYPE_R1b;
        }

        content.command = &command;
        content.data = &data;
        if (true == blockingMode)
        {
            writeStatus = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);
        }
        else
        {
            writeStatus = uSDHC_DRV_Transfer(card->host.instance, &content);
        }
    }

    return writeStatus;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_ReadData
 * Description   : read data from card.
 *
 *END**************************************************************************/
status_t T_uSDHC_ReadData(sd_card_t *card,
                          uint8_t *rxBuffer,
                          bool acmd12,
                          uint32_t blockSize,
                          uint32_t blockCount,
                          uint32_t blockAddress,
                          bool blockingMode)
{
    /* READ DATA FROM CARD
     * - Wait last write complete
     * - Send Read CMD
     */
    status_t readStatus = STATUS_ERROR;
    usdhc_transfer_t content = {0};
    usdhc_command_t command = {0};
    usdhc_data_t data = {0};

    /* send CMD13 SEND_STATUS to request card sends its status register, wait last write complete */
    readStatus == SDMMC_WaitWriteComplete(card->host.instance, card->host.transfer, card->relativeAddress);

    /* configure data */
    data.enableAutoCMD12 = acmd12;
    data.blockSize = blockSize;
    data.blockCount = blockCount;
    data.rxData = (uint32_t *)rxBuffer;

    /* configure command */
    command.index = aSDMMC_ReadSingleBlock;
    if (data.blockCount > 1U)
    {
        command.index = aSDMMC_ReadMultipleBlock;
    }
    command.argument = blockAddress;
    command.responseType = uSDHC_RESPONSE_TYPE_R1;
    if (true == data.enableAutoCMD12)
    {
        command.responseType = uSDHC_RESPONSE_TYPE_R1b;
    }

    content.command = &command;
    content.data = &data;
    if (true == blockingMode)
    {
        readStatus = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);
    }
    else
    {
        readStatus = uSDHC_DRV_Transfer(card->host.instance, &content);
    }

    return readStatus;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_EraseData
 * Description   : erase data from card.
 *
 *END**************************************************************************/
status_t T_uSDHC_EraseData(sd_card_t *card,
                          uint32_t blockCount,
                          uint32_t blockAddress,
                          bool blockingMode)
{
    /* ERASE DATA IN CARD
     * - Check ReadOnly Card
     * - Wait for card's buffer not full to write to improve write performance
     * - Wait last write complete
     * - Send EraseWriteBlockStart CMD32 to set the start block number to erase
     * - Send EraseWriteBlockEnd CMD33 to set the end block number to erase
     * - Send Erase CMD38 to start erase process
     */
    status_t eraseStatus = STATUS_ERROR;
    usdhc_transfer_t content = {0};
    usdhc_command_t command = {0};
    usdhc_data_t data = {0};

    if (true == T_uSDHC_IsCardWriteProtected(card))
    {
        eraseStatus = STATUS_ERROR;
    }
    else
    {
        T_uSDHC_WaitCardBuffer(card->host.instance);

        /* send CMD13 SEND_STATUS to request card sends its status register, wait last write complete */
        eraseStatus == SDMMC_WaitWriteComplete(card->host.instance, card->host.transfer, card->relativeAddress);

        /* send aSD_EraseWriteBlockStart CMD32 to set the start block number to erase */
        command.index = aSD_EraseWriteBlockStart;
        command.argument = blockAddress;
        command.responseType = uSDHC_RESPONSE_TYPE_R1;
        content.command = &command;
        content.data = NULL;
        if (true == blockingMode)
        {
            eraseStatus = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);
        }
        else
        {
            eraseStatus = uSDHC_DRV_Transfer(card->host.instance, &content);
        }

        /* send aSD_EraseWriteBlockEnd CMD33 to set the end block number to erase */
        command.index = aSD_EraseWriteBlockEnd;
        command.argument = blockAddress + blockCount;
        command.responseType = uSDHC_RESPONSE_TYPE_R1;
        content.command = &command;
        content.data = NULL;
        if (true == blockingMode)
        {
            eraseStatus = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);
        }
        else
        {
            eraseStatus = uSDHC_DRV_Transfer(card->host.instance, &content);
        }

        /* send aSDMMC_Erase CMD38 to start erase process */
        command.index = aSDMMC_Erase;
        command.argument = 0U;
        command.responseType = uSDHC_RESPONSE_TYPE_R1b;
        content.command = &command;
        content.data = NULL;
        if (true == blockingMode)
        {
            eraseStatus = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);
        }
        else
        {
            eraseStatus = uSDHC_DRV_Transfer(card->host.instance, &content);
        }

        /* Low-class cards need a 1 ms granularity delay between consecutive erase operations. */
        OSIF_TimeDelay(2U);
    }

    return eraseStatus;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_StopTransmission
 * Description   : stop transmission data to/from card.
 *
 *END**************************************************************************/
status_t T_uSDHC_StopTransmission(sd_card_t *card)
{
    /* STOP TRANSMISSION BETWEEN uSDHC HOST and CARD
     * - Send aSDMMC_StopTransmission CMD12
     */
    status_t status = STATUS_ERROR;
    usdhc_transfer_t content = {0};
    usdhc_command_t command = {0};

    command.index = aSDMMC_StopTransmission;
    command.argument = 0U;
    command.responseType = uSDHC_RESPONSE_TYPE_R1b;

    content.command = &command;
    content.data = NULL;
    status = uSDHC_DRV_TransferBlocking(card->host.instance, &content, T_uSDHC_TIMEOUT_MS);

    return status;
}

/*FUNCTION**********************************************************************
 *
 * Function Name : T_uSDHC_WaitTransferComplete
 * Description   : wait for transfer complete (usually in non-blocking mode).
 *
 *END**************************************************************************/
status_t T_uSDHC_WaitTransferComplete(uint32_t timeout)
{
    status_t waitStatus = STATUS_ERROR;
    while ((T_uSDHC_TC_STATE_DONE != t_g_usdhc_transferComplete) && (timeout > 0U))
    {
        /* wait for transfer complete status or until timeout */
        timeout--;
        OSIF_TimeDelay(1U);
    }

    /* update transfer complete variable */
    t_g_usdhc_transferComplete = T_uSDHC_TC_STATE_ERROR;

    if (timeout == 0U)
    {
        waitStatus = STATUS_TIMEOUT;
    }
    else
    {
        waitStatus = STATUS_SUCCESS;
    }

    return waitStatus;
}

#ifdef __cplusplus
}
#endif

/** @} */
