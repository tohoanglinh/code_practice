/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0801.c
*
*   @brief   Test case 0801.
*   @details Function test case 0801.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0801.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/
#define T_uSDHC_BUSCLOCK_400KHZ_DEVIATION              0.05
#define T_uSDHC_BUSCLOCK_25MHZ_DEVIATION               0.25
#define T_MAX_BUSCLOCK_FREQUENCY                       (40000000U)

/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0801
* @brief          Check functionality of uSDHC_DRV_SetBusClock.
* @details        This test case checks uSDHC_DRV_SetBusClock function when set bus clock frequency
*                 is set at different values, e.g. 400KHz, 25MHz and 50MHz.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*                     -# Set bus clock frequency is 400KHz
*                     -# Verification point:
*                        - Compared to the set value, the output actual bus clock value has an error deviation is 5%.
*                     -# Set bus clock frequency is 25MHz
*                     -# Verification point:
*                        - Compared to the set value, the output actual bus clock value has an error deviation is 25%.
*                     -# Set bus clock frequency is 50MHz
*                     -# Verification point:
*                        - Function returns value is the max frequency value of bus clock
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point:
*                        - Function returns STATUS_SUCCESS
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_025_001, uSDHC_025_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords       N/A
*/

void Usdhc_TC_0801(void)
{
    /* Local variable */
    uint32_t T_uSDHC_BusClockActualValue;
    uint32_t t_busClock;

    /* Initialize uSDHC module */
    (void)uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, &usdhc1_Config0);

    /* t_busClock is lower boundary value, with substracted by 1 to guarantee lower boundary 
       t_busClock < (srcClock / (uSDHC_MAX_CLKFS * uSDHC_MAX_DVS)) = (srcClock / 4096) */
    t_busClock = (uint32_t)(40000000 / (256 * 16) - 1);

    /* Set bus clock frequency to test lower boundary */
    T_uSDHC_BusClockActualValue = uSDHC_DRV_SetBusClock(INST_USDHC1, t_busClock);

    /* Set bus clock frequency is 400000U */
    T_uSDHC_BusClockActualValue = uSDHC_DRV_SetBusClock(INST_USDHC1, SDMMC_CLOCK_400KHZ);

    /* Verification point: Compared to the set value, the output actual bus clock value has an error deviation is 5%.*/
    EU_ASSERT((SDMMC_CLOCK_400KHZ - T_uSDHC_BusClockActualValue) < (T_uSDHC_BUSCLOCK_400KHZ_DEVIATION * SDMMC_CLOCK_400KHZ));

    /* Set bus clock frequency is 25MHz */
    T_uSDHC_BusClockActualValue = uSDHC_DRV_SetBusClock(INST_USDHC1, SD_CLOCK_25MHZ);

    /* Verification point: Compared to the set value, the output actual bus clock value has an error deviation is 25%.*/
    EU_ASSERT((SD_CLOCK_25MHZ - T_uSDHC_BusClockActualValue) < (T_uSDHC_BUSCLOCK_25MHZ_DEVIATION * SD_CLOCK_25MHZ));

    /* Set bus clock frequency is 50MHz */
    T_uSDHC_BusClockActualValue = uSDHC_DRV_SetBusClock(INST_USDHC1, SD_CLOCK_50MHZ);

    /* Verification point: Function returns value max frequency */
    EU_ASSERT(T_uSDHC_BusClockActualValue == T_MAX_BUSCLOCK_FREQUENCY);

    /* De-initialize uSDHC module */
    (void)uSDHC_DRV_Deinit(INST_USDHC1);
}

#ifdef __cplusplus
}
#endif

/** @} */
