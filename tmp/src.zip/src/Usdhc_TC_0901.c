/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0901.c
*
*   @brief   Test case 0901.
*   @details Function test case 0901.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0901.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/
static const IRQn_Type t_s_usdhcTxIrqId[] = uSDHC_IRQS;

/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0901
* @brief          Check functionality of uSDHC_DRV_Init and uSDHC_DRV_Deinit.
* @details        This test case checks functional of uSDHC_DRV_Init and uSDHC_DRV_Deinit.
* @pre            N/A
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - uSDHC protocol configuration is setup correctly
*                        - All auto gated off features are disabled
*                        - uSDHC byte_swapper is set
*                        - Interrupt Status Enable and Interrupt Signal Enable register is setup correctly
*                        - The interrupt for uSDHC IRQ and interrupt priority are set
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification points:
*                        - Function returns STATUS_SUCCESS
*                        - Interrupt Status Enable and Interrupt Signal Enable register are cleared
*                        - The interrupt for uSDHC IRQ and interrupt priority are cleared
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_020_001, uSDHC_020_002, uSDHC_021_001, uSDHC_021_002, uSDHC_004_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0901(void)
{
    /* Local variable */
    status_t T_uSDHC_Status = STATUS_ERROR;
    uSDHC_Type * base = g_usdhcBases[INST_USDHC1];

    /* Initialize uSDHC host driver */
    T_uSDHC_Status = uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, &usdhc1_Config0);
    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT_FATAL(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: All auto gated off features are disabled, mean that:
     * - enable ipg_perclk
     * - enable AHB clock
     * - enable bus clock
     */
    EU_ASSERT(T_uSDHC_IPG_PERCLK_ENABLED == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_AHB_CLK_ENABLED == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_HCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_HCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_BUS_CLK_ENABLED == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_SHIFT);

    /* Verification point: uSDHC byte_swapper, swaps the AHB write/read data at the boundary of uSDHC master, is setup as 4 bytes swap */
    EU_ASSERT(T_GPR_uSDHC_4BYTES_SWAP == ((GPR->CTL) & GPR_CTL_USDHC_BS_MASK) >> GPR_CTL_USDHC_BS_SHIFT);

    /* Verification point: interrupts has been enabled correctly */
    /* Verify: enable transfer command/data interrupts */
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_COMMAND_COMPLETE_INT) >> uSDHC_INT_STATUS_CC_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_COMMAND_COMPLETE_INT) >> uSDHC_INT_STATUS_CC_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DATA_COMPLETE_INT) >> uSDHC_INT_STATUS_TC_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DATA_COMPLETE_INT) >> uSDHC_INT_STATUS_TC_SHIFT);

    /* Verify: enable command error interrupts */
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_COMMAND_TIMEOUT_INT) >> uSDHC_INT_STATUS_CTOE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_COMMAND_TIMEOUT_INT) >> uSDHC_INT_STATUS_CTOE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_COMMAND_CRC_ERROR_INT) >> uSDHC_INT_STATUS_CCE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_COMMAND_CRC_ERROR_INT) >> uSDHC_INT_STATUS_CCE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_COMMAND_ENDBIT_ERROR_INT) >> uSDHC_INT_STATUS_CEBE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_COMMAND_ENDBIT_ERROR_INT) >> uSDHC_INT_STATUS_CEBE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_COMMAND_INDEX_ERROR_INT) >> uSDHC_INT_STATUS_CIE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_COMMAND_INDEX_ERROR_INT) >> uSDHC_INT_STATUS_CIE_SHIFT);

    /* Verify: enable data error interrupts */
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DATA_TIMEOUT_INT) >> uSDHC_INT_STATUS_DTOE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DATA_TIMEOUT_INT) >> uSDHC_INT_STATUS_DTOE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DATA_CRC_ERROR_INT) >> uSDHC_INT_STATUS_DCE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DATA_CRC_ERROR_INT) >> uSDHC_INT_STATUS_DCE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DATA_ENDBIT_ERROR_INT) >> uSDHC_INT_STATUS_DEBE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DATA_ENDBIT_ERROR_INT) >> uSDHC_INT_STATUS_DEBE_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_AUTO_CMD12_ERROR_INT) >> uSDHC_INT_STATUS_AC12E_SHIFT);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_AUTO_CMD12_ERROR_INT) >> uSDHC_INT_STATUS_AC12E_SHIFT);

    /* Verify: enable DMA interrupts */
    if (uSDHC_DMA_MODE_NO == usdhc1_Config0.dmaMode)
    {
        /* No DMA: Verify: enable buffer read/write ready interrupts */
        EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_BUFFER_READ_READY_INT) >> uSDHC_INT_STATUS_BRR_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_BUFFER_READ_READY_INT) >> uSDHC_INT_STATUS_BRR_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_BUFFER_WRITE_READY_INT) >> uSDHC_INT_STATUS_BWR_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_BUFFER_WRITE_READY_INT) >> uSDHC_INT_STATUS_BWR_SHIFT);
    }
    if (uSDHC_DMA_MODE_ADMA2 == usdhc1_Config0.dmaMode)
    {
        /* DMA2: Verify: enable DMA interrupt and DMA error interrupt */
        EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DMA_COMPLETE_INT) >> uSDHC_INT_STATUS_DINT_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DMA_COMPLETE_INT) >> uSDHC_INT_STATUS_DINT_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_ENABLED == ((base->INT_STATUS_EN) & uSDHC_DMA_ERROR_INT) >> uSDHC_INT_STATUS_DMAE_SHIFT);
        EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_ENABLED == ((base->INT_SIGNAL_EN) & uSDHC_DMA_ERROR_INT) >> uSDHC_INT_STATUS_DMAE_SHIFT);
    }

    /* Verification point: The interrupt for uSDHC IRQ and interrupt priority are set */
    EU_ASSERT(T_INTC_uSDHC_PROCESSOR0_SELECTED == (INTC->PSR[(int32_t)t_s_usdhcTxIrqId[INST_USDHC1]] & INTC_PSR_PRC_SELN0_MASK) >> INTC_PSR_PRC_SELN0_SHIFT);
    EU_ASSERT(T_INTC_uSDHC_PRIORITY_DEFAULT == (INTC->PSR[(int32_t)t_s_usdhcTxIrqId[INST_USDHC1]] & INTC_PSR_PRIN_MASK) >> INTC_PSR_PRIN_SHIFT);

    /* De-initialize uSDHC host driver */
    T_uSDHC_Status = uSDHC_DRV_Deinit(INST_USDHC1);
    /* Verification point: Function returns STATUS_SUCCESS */
    EU_ASSERT_FATAL(STATUS_SUCCESS == T_uSDHC_Status);

    /* Verification point: All auto gated off features are enabled, mean that:
     * - gate off ipg_perclk
     * - gate off AHB clock
     * - gate off bus clock
     */
    EU_ASSERT(T_uSDHC_IPG_PERCLK_GATED_OFF == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_IPG_PERCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_AHB_CLK_GATED_OFF == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_HCLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_HCLK_SOFT_EN_SHIFT);
    EU_ASSERT(T_uSDHC_BUS_CLK_GATED_OFF == ((base->VEND_SPEC) & uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_MASK) >> uSDHC_VEND_SPEC_BUS_CLK_SOFT_EN_SHIFT);

    /* Verification point: uSDHC byte_swapper, swaps the AHB write/read data at the boundary of uSDHC master, is setup as no swap */
    EU_ASSERT(T_GPR_uSDHC_NO_SWAP == ((GPR->CTL) & GPR_CTL_USDHC_BS_MASK) >> GPR_CTL_USDHC_BS_SHIFT);

    /* Verification point: ALL uSDHC interrupts status/signal has been disabled correctly */
    EU_ASSERT(T_uSDHC_INTERRUPT_STATUS_DISABLED == base->INT_STATUS_EN);
    EU_ASSERT(T_uSDHC_INTERRUPT_SIGNAL_DISABLED == base->INT_SIGNAL_EN);

    /* Verification point: The interrupt for uSDHC IRQ and interrupt priority are cleared */
    EU_ASSERT(T_INTC_uSDHC_PROCESSOR0_UNSELECTED == (INTC->PSR[(int32_t)t_s_usdhcTxIrqId[INST_USDHC1]] & INTC_PSR_PRC_SELN0_MASK) >> INTC_PSR_PRC_SELN0_SHIFT);
    EU_ASSERT(T_INTC_uSDHC_PRIORITY_DISABLED == (INTC->PSR[(int32_t)t_s_usdhcTxIrqId[INST_USDHC1]] & INTC_PSR_PRIN_MASK) >> INTC_PSR_PRIN_SHIFT);
}

#ifdef __cplusplus
}
#endif

/** @} */
