/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file    Usdhc_TC_0100.c
*
*   @brief   Usdhc test case 0100.
*   @details Usdhc test case 0100 for init and deinit.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "Usdhc_TC_0100.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0100
* @brief          Init and deinit with card.
* @details        Init and deinit Usdhc host driver and card.
* @pre            N/A.
* @post           N/A.
*
* @test_level     Component Validation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Invoke T_uSDHC_Init()
*                     -# Verification Point:
*                           - T_uSDHC_Init returns STATUS_SUCCESS
*                     -# Invoke T_uSDHC_Deinit()
*                     -# Verification Point:
*                           - T_uSDHC_Deinit returns STATUS_SUCCESS
* @pass_criteria  Verification Points are successful
*
* @requirements   uSDHC_020_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      Card
* @sw_depend      SDHC Middleware
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords       N/A
*/
void Usdhc_TC_0100(void)
{
    /* Local variable */
    status_t T_uSDHC_Status = STATUS_ERROR;

    /* Initialize uSDHC driver and card */
    T_uSDHC_Status = T_uSDHC_Init();
    EU_ASSERT_FATAL(STATUS_SUCCESS == T_uSDHC_Status);

    /* De-initialize uSDHC driver and card */
    T_uSDHC_Status = T_uSDHC_Deinit();
    EU_ASSERT_FATAL(STATUS_SUCCESS == T_uSDHC_Status);
}


#ifdef __cplusplus
}
#endif

/** @} */
