/**
*   Copyright 2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0903.c
*
*   @brief   Test case 0903.
*   @details Function test case 0903.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0903.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0903
* @brief          Check functionality of uSDHC_DRV_GetPresentStatusFlags.
* @details        This test case checks functional of uSDHC_DRV_GetPresentStatusFlags when there is
*                 not any configuration for pins and there is not any card in socket.
* @pre            Pins for uSDHC module are not configured and there is not any card in socket.
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Initialize the uSDHC module by calling uSDHC_DRV_Init without any
*                        configuration for pins and there is not any card in socket
*                     -# Verification point: Function returns STATUS_SUCCESS
*                     -# Get the present status of uSDHC
*                     -# Verification point: The function returns reset value of present state
*                        register except value of SD Clock Stable bit
*                     -# De-initialize the uSDHC module by calling uSDHC_DRV_Deinit
*                     -# Verification point: Function returns STATUS_SUCCESS
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_002_001, uSDHC_031_001, uSDHC_031_002
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords
*/

void Usdhc_TC_0903(void)
{
    /* Local variable */
    uint32_t usdhc_present_status_flags;

    /* Initialize uSDHC module */
    (void)uSDHC_DRV_Init(INST_USDHC1, &usdhc1_State, &usdhc1_Config0);

    /* wait before updating status of uSDHC */
    OSIF_TimeDelay(2u);

    /* Get present status flags of uSDHC host driver */
    usdhc_present_status_flags = uSDHC_DRV_GetPresentStatusFlags(INST_USDHC1);

    /* Verification point: The function returns reset value of present state register
       except value of SD Clock Stable bit */
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_COMMAND_INHIBIT) >> uSDHC_PRES_STATE_CIHB_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_DATA_INHIBIT) >> uSDHC_PRES_STATE_CDIHB_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_DATA_LINE_ACTIVE) >> uSDHC_PRES_STATE_DLA_SHIFT));
    EU_ASSERT(1U == ((usdhc_present_status_flags & uSDHC_SD_CLOCK_STABLE) >> uSDHC_PRES_STATE_SDSTB_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_WRITE_TRANSFER_ACTIVE) >> uSDHC_PRES_STATE_WTA_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_READ_TRANSFER_ACTIVE) >> uSDHC_PRES_STATE_RTA_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_BUFFER_WRITE_ENABLE) >> uSDHC_PRES_STATE_BWEN_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_BUFFER_READ_ENABLE) >> uSDHC_PRES_STATE_BREN_SHIFT));
    EU_ASSERT(1U == ((usdhc_present_status_flags & uSDHC_CARD_INSERTED) >> uSDHC_PRES_STATE_CINST_SHIFT));
    EU_ASSERT(1U == ((usdhc_present_status_flags & uSDHC_CMD_LINE_LEVEL) >> uSDHC_PRES_STATE_CLSL_SHIFT));
    EU_ASSERT(0U == ((usdhc_present_status_flags & uSDHC_WRITE_PROTECTED) >> uSDHC_PRES_STATE_WPSPL_SHIFT));

    /* De-initialize uSDHC module */
    (void)uSDHC_DRV_Deinit(INST_USDHC1);
}

#ifdef __cplusplus
}
#endif

/** @} */
