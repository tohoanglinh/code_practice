/**
*   Copyright 2017-2018 NXP
*   ALL RIGHTS RESERVED.
*   @file Usdhc_TC_0990.c
*
*   @brief   Test case 0990.
*   @details Function test case 0990.
*
*   @addtogroup [USDHC_TESTS]
*   @{
*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Usdhc_TC_0990.h"

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/*================================================================================================*/
/**
* @test_id        Usdhc_TC_0990
* @brief          Check development error detection ability in all functions when invalid parameters are passed.
* @details        Check development error detection ability in all functions when invalid parameters are passed.
* @pre            N/A.
* @post           N/A
*
* @test_level     ComponentValidation
* @test_type      Functional
* @test_technique BlackBox
* @test_procedure Steps:
*                     -# Call the uSDHC_DRV_GetPresentStatusFlags function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_GetDefaultConfig function and pass it a NULL pointer
*                     -# Verification point: An error shall be detected with a NULL pointer
*
*                     -# Call the uSDHC_DRV_Init function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*                     -# Call the uSDHC_DRV_Init function and pass it a NULL configuration pointer
*                     -# Verification point: An error shall be detected with a NULL configuration pointer
*
*                     -# Call the uSDHC_DRV_Deinit function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_Reset function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_InstallCallback function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_SetDataBusWidth function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_GetCapability function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*                     -# Call the uSDHC_DRV_GetCapability function and pass it a NULL capability pointer
*                     -# Verification point: An error shall be detected with a NULL capability pointer
*
*                     -# Call the uSDHC_DRV_SetBusClock function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*                     -# Call the uSDHC_DRV_SetBusClock function and pass it an invalid bus clock frequency
*                     -# Verification point: An error shall be detected with an invalid bus clock frequency
*
*                     -# Call the uSDHC_DRV_SetCardActive function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
*                     -# Call the uSDHC_DRV_TransferBlocking function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*                     -# Call the uSDHC_DRV_TransferBlocking function and pass it a NULL transfer pointer
*                     -# Verification point: An error shall be detected with a NULL transfer pointer
*                     -# Call the uSDHC_DRV_TransferBlocking function and pass it an invalid content
*                        with NULL command transfer pointer
*                     -# Verification point: An error shall be detected with an invalid content
*                        with NULL command transfer pointer
*
*                     -# Call the uSDHC_DRV_Transfer function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*                     -# Call the uSDHC_DRV_Transfer function and pass it a NULL transfer pointer
*                     -# Verification point: An error shall be detected with a NULL transfer pointer
*                     -# Call the uSDHC_DRV_Transfer function and pass it an invalid content
*                        with NULL command transfer pointer
*                     -# Verification point: An error shall be detected with an invalid content
*                        with NULL command transfer pointer
*
*                     -# Call the uSDHC_DRV_EnableCardControl function and pass it an invalid instance number
*                     -# Verification point: An error shall be detected with an invalid instance number
*
* @pass_criteria  Verification points are successful
*
* @requirements   uSDHC_031_002, uSDHC_019_002, uSDHC_020_002, uSDHC_021_002, uSDHC_022_002,
*                 uSDHC_023_002, uSDHC_027_002, uSDHC_024_002, uSDHC_025_002, uSDHC_026_002,
*                 uSDHC_028_002, uSDHC_029_002, uSDHC_030_001
* @traceability   N/A
* @execution_type Automated
* @hw_depend      N/A
* @sw_depend      N/A
* @boundary_test  N/A
* @defects        N/A
* @test_priority  High
* @note           N/A
* @keywords       N/A
*/

void Usdhc_TC_0990(void)
{
    /* Local variable */
    usdhc_capability_t T_get_usdhc_capability;

    usdhc_transfer_t invalid_content = {0};
    invalid_content.command = NULL;
    invalid_content.data = NULL;

    usdhc_command_t command1 = {0};
    command1.index = aSDMMC_GoIdleState;

    usdhc_transfer_t content = {0};
    content.command = &command1;
    content.data = 0U;

    /* static inline uint32_t uSDHC_DRV_GetPresentStatusFlags(uint32_t instance)
     * Get the status of uSDHC
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_GetPresentStatusFlags(T_uSDHC_INVALID_INSTANCE);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* void uSDHC_DRV_GetDefaultConfig(usdhc_config_t * config)
     * Gets the default configuration structure
     * Invalid: config == NULL
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_GetDefaultConfig(NULL);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_Init(uint32_t instance,
                        usdhc_state_t * state,
                        const usdhc_config_t * config)
     * Initialize a uSDHC module
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     * Invalid: config == NULL
     * Invalid: config->dmaMode == uSDHC_DMA_MODE_ADMA1 (if !defined uSDHC_ENABLE_ADMA1)
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Init(T_uSDHC_INVALID_INSTANCE,
                       &usdhc1_State,
                       &usdhc1_Config0);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Init(INST_USDHC1,
                       &usdhc1_State,
                       NULL);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_Deinit(uint32_t instance)
     * De-initialize a uSDHC module
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Deinit(T_uSDHC_INVALID_INSTANCE);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_Reset(uint32_t instance,
                         uint32_t mask,
                         uint32_t timeoutMs)
     * Reset the uSDHC module
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Reset(T_uSDHC_INVALID_INSTANCE,
                        T_uSDHC_RESET_MASK,
                        T_uSDHC_TIMEOUT_MS);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* void uSDHC_DRV_InstallCallback(uint32_t instance,
                               usdhc_event_t event,
                               usdhc_callback_t function,
                               void * param)
     * Register the callback functions for uSDHC events
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_InstallCallback(T_uSDHC_INVALID_INSTANCE,
                                  uSDHC_EVENT_TRANSFER_COMPLETE,
                                  T_uSDHC_TransferCompleteCallback,
                                  NULL);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* void uSDHC_DRV_SetDataBusWidth(uint32_t instance,
                               usdhc_data_bus_width_t width)
     * Set data bus width for uSDHC module
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_SetDataBusWidth(T_uSDHC_INVALID_INSTANCE,
                                  uSDHC_DATA_BUS_WIDTH_4BIT);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* void uSDHC_DRV_GetCapability(uint32_t instance,
                                    usdhc_capability_t * capability)
     * Get supported capability of uSDHC module
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     * Invalid: capability == NULL
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_GetCapability(T_uSDHC_INVALID_INSTANCE,
                                &T_get_usdhc_capability);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_GetCapability(INST_USDHC1,
                                NULL);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* uint32_t uSDHC_DRV_SetBusClock(uint32_t instance,
                                      uint32_t busClock)
     * Set SD bus clock frequency.
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     * Invalid: busClock <= 0
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_SetBusClock(T_uSDHC_INVALID_INSTANCE,
                              T_uSDHC_BUS_CLOCK);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_SetBusClock(INST_USDHC1,
                              0U);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_SetCardActive(uint32_t instance,
                                        uint32_t timeoutMs)
     * Send 80 clock cycles to card to activate the card
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_SetCardActive(T_uSDHC_INVALID_INSTANCE,
                                T_uSDHC_TIMEOUT_MS);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_TransferBlocking(uint32_t instance,
                                    usdhc_transfer_t * transfer,
                                    uint32_t timeoutMs)
     * Send a command or data using blocking mode to the card and get the response from card if any
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     * Invalid: transfer == NULL
     * Invalid: transfer->command == NULL
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_TransferBlocking(T_uSDHC_INVALID_INSTANCE,
                                   &content,
                                   T_uSDHC_TIMEOUT_MS);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_TransferBlocking(INST_USDHC1,
                                   NULL,
                                   T_uSDHC_TIMEOUT_MS);
    }

    /* Check an error shall be detected with invalid configuration */
    EU_ASSERT(Dev_ErrorId == 1);
    Dev_ErrorId = 0;

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_TransferBlocking(INST_USDHC1,
                                   &invalid_content,
                                   T_uSDHC_TIMEOUT_MS);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* status_t uSDHC_DRV_Transfer(uint32_t instance,
                            usdhc_transfer_t * transfer)
     * Send a command or data using non-blocking mode to the card and get the response from card if any
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     * Invalid: transfer == NULL
     * Invalid: transfer->command == NULL
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Transfer(T_uSDHC_INVALID_INSTANCE,
                           &content);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Transfer(INST_USDHC1,
                           NULL);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_Transfer(INST_USDHC1,
                           &invalid_content);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();

    /* void uSDHC_DRV_EnableCardControl(uint32_t instance,
                                        uint32_t mask,
                                        bool enable)
     * Enable or disable some features for uSDHC
     * Invalid: instance >= uSDHC_INSTANCE_COUNT
     */
    if (setjmp(bufferA) == 0)
    {
        uSDHC_DRV_EnableCardControl(T_uSDHC_INVALID_INSTANCE,
                                    uSDHC_WAKEUP_ON_CARD_INT,
                                    true);
    }

    /* Check an error shall be detected with invalid configuration */
    T_CheckDevError();
}

#ifdef __cplusplus
}
#endif

/** @} */
